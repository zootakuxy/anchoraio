"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioApplicationManager = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const ini_1 = __importDefault(require("ini"));
const nanoid_1 = require("nanoid");
const aio_1 = require("../socket/aio");
const server_1 = require("../anchor/server");
const Application_1 = require("../applications/Application");
class AioApplicationManager {
    constructor(agent) {
        this.seq = 0;
        this.applications = [];
        this.agent = agent;
        let exists = fs.existsSync(path.join(agent.opts.etc, "apps.conf"));
        this.appsConf = exists ? ini_1.default.parse(fs.readFileSync(path.join(agent.opts.etc, "apps.conf")).toString("utf8")) : { apps: {} };
        this.applications.push(...(0, Application_1.discoverApplications)());
    }
    registerApplication(application, app) {
        if (!application)
            application = "default";
        let _app = this.appsConf.apps[application];
        if (!_app && app) {
            // @ts-ignore
            _app = app;
            this.appsConf.apps[application] = _app;
            fs.writeFile(path.join(this.agent.opts.etc, "apps.conf"), ini_1.default.stringify(this.appsConf, {
                whitespace: true
            }), () => { });
        }
        return _app;
    }
    connectApplication(args) {
        let application = this.getApplication(args.application);
        let connection;
        if (application) {
            let resolverId = `resolver://${this.agent.identifier}/${(0, nanoid_1.nanoid)(16)}?${this.seq++}`;
            connection = aio_1.aio.connect({
                host: application.address,
                port: Number(application.port),
                listenEvent: false,
                id: resolverId,
                isConnected: false,
                autoReconnect: null
            });
            connection.on("error", err => {
                console.error("[ANCHORIO] Agent>", `Application Connection error ${err.message}`);
            });
            connection = this.agent.anchorServer.register(connection, { anchorPoint: "SERVER" });
            this.agent.anchorServer.auth({
                aioType: server_1.AioType.AIO_OUT,
                anchors: [connection.id],
                busy: connection.id,
                origin: this.agent.identifier,
                needOpts: {}
            }, this.agent.connect.id, { onError: "END", name: "SERVER" });
        }
        return connection;
    }
    getApplication(application) {
        if (!application)
            application = "default";
        let app = this.appsConf.apps[application];
        let _app;
        if (app && typeof app === "object" && Number.isSafeInteger(Number(app.port))) {
            _app = app;
        }
        else if ((typeof app === "string" || typeof app === "number") && Number.isSafeInteger(Number(app))) {
            _app = {
                port: Number(app),
                address: "127.0.0.1",
                name: application
            };
        }
        else if (typeof app === "string" || typeof app === "number")
            _app = null;
        return _app;
    }
    transform(meta, data, direction) {
        // if( direction === TransactionDirection.CLIENT_TO_SERVER ) console.log({meta, data, direction});
        var _a;
        if (!((_a = meta === null || meta === void 0 ? void 0 : meta.appConf) === null || _a === void 0 ? void 0 : _a.reference))
            return data;
        let application = this.applications.find(value => !!value.name
            && value.name === meta.appConf.reference);
        if (!application)
            return data;
        let transform = application.transform(meta, data, meta.appConf, direction);
        if (!!transform)
            data = transform;
        return data;
    }
}
exports.AioApplicationManager = AioApplicationManager;
//# sourceMappingURL=aio-application-manager.js.map