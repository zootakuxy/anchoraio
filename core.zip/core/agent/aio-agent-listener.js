"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioAgentListener = void 0;
const share_1 = require("../anchor/share");
const chalk_1 = __importDefault(require("chalk"));
const server_1 = require("../anchor/server");
class AioAgentListener {
    constructor(connect) {
        this._connect = connect;
        this._agent = connect.agent;
        this.listen(this.server);
    }
    listen(connection) {
        connection.onListen("auth", (identifier, _private) => this.onAgentAuth(identifier, _private));
        connection.onListen(share_1.Event.SLOTS, (args) => this.onSlot(args));
        connection.onListen(share_1.Event.AIO, (args) => this.onAio(args));
        connection.onListen(share_1.Event.AIO_CANCELLED, (args) => this.onAioCansel(args));
        connection.onListen(share_1.Event.AIO_SEND, (args) => {
            this.onAioSend(args);
        });
        connection.onListen(share_1.Event.AIO_REJECTED, (args) => {
            this.onAioReject(args);
        });
        connection.onListen(share_1.Event.AIO_ANCHORED, (args) => this.onAioAnchored(args));
        connection.onListen(share_1.Event.AIO_END_ERROR, (args) => this.onAioEndError(args));
        connection.onListen("*", (event, args) => {
            if ([share_1.Event.AIO_REJECTED, share_1.Event.AIO_ANCHORED, share_1.Event.AIO_CANCELLED].includes(event)) {
                this.onAioEnd(event, args);
            }
        });
    }
    get server() { return this._connect.server; }
    get connect() {
        return this._connect;
    }
    get agent() {
        return this._agent;
    }
    onAgentAuth(identifier, _private) {
        if (identifier) {
            this.connect.createChanel();
            if (this.agent.anchorServer.counts(server_1.AioType.AIO_IN, this.agent.identifier) < this.agent.opts.minSlots)
                this.connect.needAnchor(server_1.AioType.AIO_IN).then();
            if (this.agent.anchorServer.counts(server_1.AioType.AIO_OUT, this.agent.identifier) < this.agent.opts.minSlots)
                this.connect.needAnchor(server_1.AioType.AIO_OUT).then();
            console.log("[ANCHORIO] Agent>", `Connected to server aio://${this.agent.opts.serverHost}:${this.agent.opts.serverPort} with id ${chalk_1.default.blueBright(this.connect.id)} ${chalk_1.default.greenBright(`\\AUTHENTICATED-IN-SERVER`)}`);
        }
        else {
            console.log("[ANCHORIO] Agent>", chalk_1.default.redBright(`Auth rejected from server with message ${_private.message} \\SERVER REJECTION`));
            this.connect.server.close();
        }
    }
    onSlot(args) {
        let slot = args.aioType;
        let opts = args.needOpts;
        this.connect.needAnchor(slot, this.agent.identifier, opts).catch(reason => { });
        console.log("[ANCHORIO] Agent>", `Server need more anchor slots ${chalk_1.default.blueBright(slot)} code: ${chalk_1.default.blueBright(opts.key)}!`);
    }
    onAio(args) {
        this.agent.anchorServer.nextSlot(server_1.AioType.AIO_IN, this.agent.identifier, args.anchor_to).then(anchor => {
            let application = this.agent.appManager.connectApplication(args);
            if (application) {
                this.agent.anchorServer.anchor(anchor, application, args.request, args.application);
                this.connect.server.send(share_1.Event.AIO_ANCHORED, args);
                console.log(`[ANCHORIO] Agent>`, `Anchor form ${args.origin} to application ${args.application}@${this.agent.identifier} ${chalk_1.default.greenBright("\\CONNECTED!")}`);
            }
            else {
                console.log(`[ANCHORIO] Agent>`, `Anchor form ${args.origin} to application ${args.application}@${this.agent.identifier} not found connection ${chalk_1.default.redBright("\\REJECTED!")}`);
                this.connect.server.send(share_1.Event.AIO_REJECTED, args);
                anchor.close();
            }
        });
    }
    onAioCansel(args) {
        console.log(`[ANCHORIO] Agent>`, chalk_1.default.redBright(`Anchor form ${args.origin} to application ${args.application} not found connection \\REJECTED!`));
    }
    onAioSend(args) {
        let request = this.agent.anchorServer.of(args.request);
        if (!request)
            return;
    }
    onAioReject(args) {
        let request = this.agent.anchorServer.of(args.request);
        if (!request)
            return;
        request.meta.extras.result = "rejected";
        console.log(`[ANCHORIO] Agent>`, `Anchor form local ${args.origin} to remote application ${args.application}@${args.server} not found connection ${chalk_1.default.redBright("\\REJECTED!")}`);
    }
    onAioAnchored(args) {
        let request = this.agent.anchorServer.of(args.request);
        if (!request)
            return;
        request.meta.extras.result = "success";
        console.log(`[ANCHORIO] Agent>`, `Anchor form local ${args.origin} to remote application ${args.application}@${args.server} ${chalk_1.default.greenBright("\\CONNECTED")}!`);
    }
    onAioEnd(event, args) {
        let request = this.agent.anchorServer.of(args.request);
        let anchor = this.agent.anchorServer.of(args.anchor_form);
        if (request)
            request.meta.extras.status = "complete";
        if (event !== share_1.Event.AIO_ANCHORED) {
            console.log("[ANCHORIO] Agent>", chalk_1.default.redBright(`Request ${args.request} end without success`));
            request === null || request === void 0 ? void 0 : request.close();
            anchor.close();
        }
    }
    onAioEndError(args) {
        this.agent.anchorServer.filterSocketByMeta(meta => meta.anchorRequest === args.request).forEach(value => {
            value.close();
        });
    }
}
exports.AioAgentListener = AioAgentListener;
//# sourceMappingURL=aio-agent-listener.js.map