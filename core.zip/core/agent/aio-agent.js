"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioAgent = void 0;
const aio_agent_connect_1 = require("./aio-agent-connect");
const aio_resolve_1 = require("../dns/aio.resolve");
const chalk_1 = __importDefault(require("chalk"));
const server_1 = require("../anchor/server");
const aio_application_manager_1 = require("./aio-application-manager");
const aio_agent_request_1 = require("./aio-agent-request");
const nanoid_1 = require("nanoid");
const token_service_1 = require("../service/token.service");
class AioAgent {
    constructor(context) {
        let self = this;
        this._opts = context.options;
        this._identifier = context.options.identifier;
        this._context = context;
        this._instance = `${(0, nanoid_1.nanoid)(32)}::${new Date().getTime()}@${this.opts.identifier}`;
        let tokenService = new token_service_1.TokenService(context.options);
        this._token = tokenService.token;
        if (!this.token) {
            console.log(chalk_1.default.redBright(`Token for ${this.opts.identifier} not found or is invalid!`));
            process.exit(0);
        }
        this._connect = new aio_agent_connect_1.AioAgentConnect(this);
        this._anchorServer = new server_1.AioAnchorServer(this, {
            listen: [this.opts.agentPort],
            sendHeader: false,
            identifier: this.identifier,
            minSlots: this.opts.minSlots,
            maxSlots: this.opts.maxSlots,
            anchorPoint: "CLIENT",
            onNeedAnchor: (type, server, opts) => {
                return this.connect.needAnchor(type, server, opts);
            }, emit(server, event, opts) {
                self.connect.server.emit(event, opts);
            }
        });
        this._appManager = new aio_application_manager_1.AioApplicationManager(this);
        this._aioResolve = new aio_resolve_1.AioResolver(this);
        this._request = new aio_agent_request_1.AioAgentRequest(this);
        this._context.listener.on("context.start:sync", any => {
            return this.anchorServer.start(() => {
                console.log("[ANCHORIO] Agent>", `Running Agent Proxy ${this.identifier} on port ${chalk_1.default.greenBright(String(this.opts.agentPort))}`);
            });
        });
    }
    get isConnected() {
        return this.connect.server.connected;
    }
    get isAvailable() {
        return this.connect.server.connected && this.connect.authStatus === "accepted";
    }
    get instance() {
        return this._instance;
    }
    get identifier() {
        return this._identifier;
    }
    get opts() {
        return this._opts;
    }
    get server() {
        return this._server;
    }
    get connect() {
        return this._connect;
    }
    get anchorServer() {
        return this._anchorServer;
    }
    get agent() {
        return this;
    }
    get appManager() {
        return this._appManager;
    }
    get request() {
        return this._request;
    }
    get token() {
        return this._token;
    }
    get aioResolve() {
        return this._aioResolve;
    }
}
exports.AioAgent = AioAgent;
//# sourceMappingURL=aio-agent.js.map