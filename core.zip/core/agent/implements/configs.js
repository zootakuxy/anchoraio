"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configs = void 0;
const dir_watch_1 = require("../../utils/dir-watch");
class Configs {
    constructor(context) {
        this.context = context;
        this.dirWatch = new dir_watch_1.DirWatch();
    }
}
exports.Configs = Configs;
//# sourceMappingURL=configs.js.map