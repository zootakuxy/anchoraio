"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentContext = void 0;
const api_1 = require("../dns/api");
const server_1 = require("../dns/server");
const aio_agent_1 = require("./aio-agent");
const listener_1 = require("../utils/listener");
const status_1 = require("../utils/status");
class AgentContext {
    constructor(agentOpts) {
        this.options = agentOpts;
        this._status = new status_1.Status();
        this.listener = new listener_1.Listener();
        this.agent = new aio_agent_1.AioAgent(this);
        this.agentDNS = new server_1.AgentDNS(this);
        this.agentApi = new api_1.AgentAPI(this);
    }
    stop() {
        this._status.stop(() => {
            return this.listener.notifyAll("context.stop");
        });
    }
    start() {
        return this._status.start(() => {
            return this.listener.notifyAll("context.start");
        });
    }
    get status() {
        return this._status.status;
    }
}
exports.AgentContext = AgentContext;
//# sourceMappingURL=agent-context.js.map