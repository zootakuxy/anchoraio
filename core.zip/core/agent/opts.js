"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentOptsBuilder = void 0;
const aio_1 = require("../socket/aio");
const lib_1 = require("../lib");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
function agentOptsBuilder(yargs) {
    yargs.option("identifier", { alias: ["id", "i"],
        type: "string",
        coerce: lib_1.lib.typeParser.asString,
        description: "Identificador unico do agent",
        demandOption: true
    });
    yargs.check(argv => {
        var _a;
        let identifier = (_a = argv._[1]) !== null && _a !== void 0 ? _a : argv.identifier;
        let result = typeof identifier === "string"
            && identifier.trim().length
            && identifier === identifier.toLowerCase();
        if (!result)
            throw new Error("Invalid or missing agent identifier");
        return true;
    });
    yargs.option("serverHost", { alias: ["h", "host"],
        type: "string",
        default: aio_1.aio.Defaults.serverHost,
        coerce: lib_1.lib.typeParser.asString,
        demandOption: true
    });
    yargs.option("serverPort", {
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.serverPort
    });
    yargs.option("agentPort", { alias: ["port", "p"],
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.agentPort,
        demandOption: true
    });
    yargs.option("agentAPI", { alias: ["api", "a"],
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.agentAPI,
        demandOption: true
    });
    yargs.option("anchorPort", { alias: ["P"],
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.anchorPort
    });
    yargs.option("dnsPort", {
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.dnsPort
    });
    yargs.option("dns", {
        type: "string",
        array: true,
        default: aio_1.aio.Defaults.dns,
        coerce: lib_1.lib.typeParser.asStringArray
    });
    yargs.option("reconnectTimeout", {
        type: "number",
        default: aio_1.aio.Defaults.reconnectTimeout,
        coerce: lib_1.lib.typeParser.asInt,
        demandOption: true
    });
    yargs.option("noDNS", {
        type: "boolean",
        description: "Disable dns server"
    });
    yargs.option("noAPI", {
        type: "boolean",
        description: "Disable api"
    });
    yargs.option("selfServer", {
        type: "boolean",
        description: "Start self server"
    });
    let noPortVar = path_1.default.join(__dirname, "../../../noport/var");
    if (!fs_1.default.existsSync(noPortVar))
        noPortVar = null;
    if (!!noPortVar && !fs_1.default.statSync(noPortVar).isDirectory())
        noPortVar = null;
    yargs.option("noPortVar", {
        type: "string",
        description: "No port home dir",
        //language=file-reference
        default: noPortVar,
        coerce: arg => {
            if (!arg)
                return null;
            if (!path_1.default.isAbsolute(arg))
                arg = path_1.default.join(process.cwd(), arg);
            if (!fs_1.default.existsSync(arg))
                return null;
            if (!fs_1.default.statSync(arg).isDirectory())
                return null;
            return arg;
        }
    });
    yargs.option("chanel", {
        type: "number",
        default: aio_1.aio.Defaults.chanel,
        demandOption: true,
        coerce: lib_1.lib.typeParser.asInt
    });
    return yargs;
}
exports.agentOptsBuilder = agentOptsBuilder;
//# sourceMappingURL=opts.js.map