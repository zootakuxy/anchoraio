"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioAgentConnect = void 0;
const share_1 = require("../anchor/share");
const aio_agent_listener_1 = require("./aio-agent-listener");
const aio_1 = require("../socket/aio");
const chalk_1 = __importDefault(require("chalk"));
class AioAgentConnect {
    constructor(aioAgent) {
        this.chanel = [];
        this._authStatus = "unknown";
        this._agent = aioAgent;
        let self = this;
        this._server = aio_1.aio.connect({
            host: this._agent.opts.serverHost,
            port: this._agent.opts.serverPort,
            listenEvent: true,
            isConnected: false,
            auth: share_1.HEADER.auth({
                origin: self._agent.identifier,
                server: self._agent.identifier,
                token: self.agent.token.token,
                level: "primary",
                instance: self.agent.instance
            }),
            autoReconnect: () => this.autoReconnect()
        });
        this._server.onListen("auth", (identifier, authResult) => {
            if (!identifier) {
                this._id = null;
                this._authStatus = "rejected";
                this._anchorPort = null;
                return;
            }
            this._id = identifier;
            this._anchorPort = authResult.anchorPort;
            this._authStatus = "accepted";
            this.agent.request.continue();
        });
        this._listener = new aio_agent_listener_1.AioAgentListener(this);
        this.server.on("error", err => this._id = null);
        this.server.on("close", hadError => this._id = null);
    }
    get id() {
        return this._id;
    }
    get server() {
        return this._server;
    }
    get agent() {
        return this._agent;
    }
    get authStatus() {
        return this._authStatus;
    }
    get anchorPort() {
        return this._anchorPort;
    }
    autoReconnect() {
        return { port: this.agent.opts.serverPort, host: this.agent.opts.serverHost };
    }
    needAnchor(type, _server, opts) {
        if (!opts)
            opts = {};
        return new Promise((resolve) => {
            let counts = (this.agent.opts.maxSlots || 1) - this.agent.anchorServer.counts(type, this.agent.identifier);
            if (!counts || counts < 1)
                counts = 1;
            // counts = 1;
            let created = 0;
            let resolved = false;
            if (!counts)
                return resolve(null);
            let _anchors = [];
            let _busy;
            let _sockets = [];
            for (let i = 0; i < counts; i++) {
                let _canReconnect = true;
                const aioAnchor = aio_1.aio.connect({
                    host: this.agent.opts.serverHost,
                    port: this.anchorPort,
                    listenEvent: true,
                    isConnected: false,
                    autoReconnect: () => {
                        if (_canReconnect)
                            return {
                                port: this.anchorPort,
                                host: this.agent.opts.serverHost
                            };
                    }
                });
                aioAnchor.on("connect", () => {
                    _canReconnect = false;
                });
                aioAnchor.onListen("auth", id => {
                    this.agent.anchorServer.register(aioAnchor, { anchorPoint: "CONNECTION" });
                    _sockets.push(aioAnchor);
                    if ((opts === null || opts === void 0 ? void 0 : opts.busy) && !_busy)
                        _busy = aioAnchor.id;
                    let auth_ = {
                        anchors: [aioAnchor.id],
                        busy: _busy,
                        aioType: type,
                        origin: this.agent.identifier,
                        needOpts: opts,
                    };
                    this.agent.anchorServer.auth(auth_, this.id, { onError: "RESTORE", name: `${type}-CONNECTION` });
                    created++;
                    if ((opts === null || opts === void 0 ? void 0 : opts.busy) && !resolved) {
                        resolved = true;
                        resolve(_sockets.find(value => value.id === _busy));
                    }
                    if (created === counts && !resolved) {
                        resolved = true;
                        resolve(_sockets.find(value => value.id !== _busy));
                    }
                    _anchors.push(aioAnchor.id);
                    let pack = share_1.HEADER.slot({
                        aioType: type,
                        busy: _busy,
                        origin: this.agent.identifier,
                        anchors: _anchors,
                        needOpts: opts
                    });
                    if (created === counts) {
                        this.server.send(share_1.Event.SLOTS, pack);
                    }
                });
            }
        });
    }
    createChanel() {
        this.chanel.forEach(chanel => {
            if (chanel.connected)
                chanel.close();
        });
        this.chanel.length = 0;
        for (let i = 0; i < (this.agent.opts.chanel || 2); i++) {
            let auth = share_1.HEADER.auth({
                level: "secondary",
                origin: this.agent.identifier,
                server: this.agent.identifier,
                referer: this.id,
                token: this.agent.token.token,
                instance: this.agent.instance
            });
            let connection = aio_1.aio.connect({
                host: this.agent.opts.serverHost,
                port: this.agent.opts.serverPort,
                listenEvent: true,
                isConnected: false,
                auth: auth
            });
            connection.onListen("auth", (identifier, auth) => {
                if (!identifier) {
                    console.log("[ANCHORIO] Agent>", chalk_1.default.redBright(`Create new chanel rejected by server with ${auth === null || auth === void 0 ? void 0 : auth.message}!`));
                    return;
                }
                this.chanel.push(connection);
                this._listener.listen(connection);
                console.log("[ANCHORIO] Agent>", `Create new chanel ${chalk_1.default.blueBright(connection.id)}  referer ${this.id}!`);
            });
        }
    }
}
exports.AioAgentConnect = AioAgentConnect;
//# sourceMappingURL=aio-agent-connect.js.map