"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioAgentRequest = void 0;
const server_1 = require("../anchor/server");
const share_1 = require("../anchor/share");
const chalk_1 = __importDefault(require("chalk"));
class AioAgentRequest {
    constructor(agent) {
        this._pendentsRequest = [];
        this._agent = agent;
        this.agent.anchorServer.onConnection(aioSocket => {
            this.onConnection(aioSocket);
        });
    }
    get agent() {
        return this._agent;
    }
    continue() {
        this._pendentsRequest.splice(0, this._pendentsRequest.length).forEach(value => {
            this.startAnchor(value);
        });
    }
    startAnchor(req) {
        req.meta.extras.status = "income";
        this.agent.anchorServer.auth({
            anchors: [req.id],
            aioType: server_1.AioType.AIO_IN,
            busy: req.id,
            origin: this.agent.identifier,
            needOpts: {},
        }, this.agent.connect.id, { onError: "END", name: "REQUEST" });
        console.log("[ANCHORIO] Agent>", `Anchor request ${req.id} started!`);
        let resolved = req.meta.extras.resolved;
        this.agent.anchorServer.nextSlot(server_1.AioType.AIO_OUT, this.agent.identifier).then(connection => {
            if (!connection) {
                console.log("[ANCHORIO] Request>", this.agent.identifier, resolved.application, "\\", chalk_1.default.redBright("rejected"));
                return req.close();
            }
            let pack;
            this.agent.connect.server.send(share_1.Event.AIO, pack = share_1.HEADER.aio({
                origin: this.agent.identifier,
                server: resolved.serverIdentifier,
                request: req.id,
                application: resolved.application,
                domainName: resolved.domainName,
                anchor_form: connection.id
            }));
            this.agent.anchorServer.anchor(req, connection, pack.request, pack.application);
            console.log("[ANCHORIO] Agent>", `New request id ${req.id} from ${this.agent.identifier} to ${pack.application}@${pack.server} ${chalk_1.default.blueBright("\\ACCEPTED AIO ANCHOR")}`);
        });
    }
    onConnection(req) {
        req.meta.extras = req.meta.extras || {};
        req.meta.extras.type = "local-request";
        let rejectConnection = (message) => {
            console.log("[ANCHORIO] Agent>", `${chalk_1.default.redBright("Rejected new request connection")}.  ${message || ""}`);
            req.end(() => { });
        };
        let acceptConnection = (resolved) => {
            console.log("[ANCHORIO] Agent>", `${chalk_1.default.greenBright("Accepted new request connection")}`);
            req.meta.extras.resolved = resolved;
            if (this.agent.connect.authStatus === "accepted")
                this.startAnchor(req);
            else
                this._pendentsRequest.push(req);
        };
        if (!this.agent.isAvailable) {
            let status = "";
            if (!this.agent.isConnected)
                status = "disconnected";
            if (this.agent.connect.authStatus !== "accepted")
                status += ` ${this.agent.connect.authStatus}`;
        }
        req.on("error", err => { console.log("[ANCHORIO] Agent>", `Request ID ${req.id} socket error ${err.message}`); });
        const remoteAddressParts = req.address()["address"].split(":");
        const address = remoteAddressParts[remoteAddressParts.length - 1];
        let resolved = this.agent.aioResolve.resolved(address);
        if (!resolved)
            return rejectConnection(`no resolved answerer domain found from address ${address}`);
        acceptConnection(resolved);
    }
}
exports.AioAgentRequest = AioAgentRequest;
//# sourceMappingURL=aio-agent-request.js.map