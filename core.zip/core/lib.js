"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lib = void 0;
var lib;
(function (lib) {
    lib.typeParser = {
        isInt(any) { return Number.isSafeInteger(Number(any)); },
        isNumber(any) { return !Number.isNaN(Number(any)) && Number.isFinite(Number(any)); },
        asInt(any) { return lib.typeParser.isInt(any) ? Number(any) : undefined; },
        toInt(any) { return this.asInt(Math.trunc(Number(any))); },
        asNumber(any) { return lib.typeParser.isNumber(any) ? Number(any) : undefined; },
        asString(any) { var _a; return (_a = any === null || any === void 0 ? void 0 : any.toString) === null || _a === void 0 ? void 0 : _a.call(any); },
        asStringArray(any) {
            if (!Array.isArray(any))
                any = [any];
            return any.map(value => {
                var _a;
                return (_a = value === null || value === void 0 ? void 0 : value.toString) === null || _a === void 0 ? void 0 : _a.call(value);
            });
        }
    };
    function proxyOfArray() {
        return new Proxy({}, {
            get(target, p, receiver) {
                if (!target[p])
                    target[p] = [];
                return target[p];
            }
        });
    }
    lib.proxyOfArray = proxyOfArray;
})(lib = exports.lib || (exports.lib = {}));
//# sourceMappingURL=lib.js.map