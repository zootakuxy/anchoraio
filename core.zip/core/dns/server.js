"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentDNS = void 0;
const chalk_1 = __importDefault(require("chalk"));
const dns2 = require('dns2');
const net_resolve_1 = require("./net.resolve");
const { Packet } = dns2;
class AgentDNS {
    constructor(context) {
        this.context = context;
        this.netResolver = new net_resolve_1.NetResolver(this.context);
        this.server = dns2.createServer({
            udp: true,
            tcp: true,
            handle: (request, send, rinfo) => {
                const response = Packet.createResponseFromRequest(request);
                const [question] = request.questions;
                const { name } = question;
                let aioResponse = context.agent.aioResolve.aioResolve(name);
                if (aioResponse && aioResponse.length > 0) {
                    console.log("[dns resolve]", name, "\\", "127.0.0.1");
                    response.answers.push(...aioResponse);
                    send(response);
                    return;
                }
                else {
                    this.netResolver.resolve(name).then(result => {
                        if (result.answers.length)
                            console.log("[dns resolve]", result.server, "\\", "127.0.0.1");
                        response.answers.push(...result.answers);
                        send(response);
                    });
                }
            }
        });
        this.server.on('close', () => {
            console.log('[ANCHORIO] DNS>', "OFF");
        });
    }
    start() {
        this.server.listen({
            udp: this.context.options.dnsPort,
            tcp: this.context.options.dnsPort
        }).then(value => {
            console.log("[ANCHORIO] Agent>", chalk_1.default.greenBright(`Running Agent DNS SERVER ${this.context.options.identifier} on port ${this.context.options.dnsPort}`));
        });
    }
}
exports.AgentDNS = AgentDNS;
//# sourceMappingURL=server.js.map