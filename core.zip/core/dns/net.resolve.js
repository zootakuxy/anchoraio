"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NetResolver = void 0;
const moment_1 = __importDefault(require("moment"));
const { TCPClient } = require('dns2');
class NetResolver {
    constructor(context) {
        this.resolves = {};
        this.context = context;
        this.dnsResolves = this.context.options.dns.map(name => {
            return { resolve: TCPClient(name), name };
        });
    }
    resolve(domainName) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((_resolve, reject) => {
                let resolve = (a, dns) => {
                    resolve = () => { };
                    this.resolves[domainName] = a;
                    _resolve({
                        answers: a,
                        server: dns.name
                    });
                };
                if (!this.dnsResolves.length) {
                    return resolve([], { name: "NOTFOUND" });
                }
                let exists = this.resolves[domainName];
                if (exists)
                    return Promise.resolve(exists);
                let count = this.dnsResolves.length;
                let next = (dns, result) => {
                    var _a;
                    count--;
                    if (((_a = result === null || result === void 0 ? void 0 : result.answers) === null || _a === void 0 ? void 0 : _a.length) > 0)
                        resolve(result === null || result === void 0 ? void 0 : result.answers, dns);
                    else if (count === 0)
                        resolve([], dns);
                };
                this.dnsResolves.forEach(dns => {
                    dns.resolve(domainName).then((result) => {
                        next(dns, result);
                    }).catch(reason => {
                        next(dns, null);
                        console.error("dns error", (0, moment_1.default)(), dns.name, reason.message);
                    });
                });
            });
        });
    }
}
exports.NetResolver = NetResolver;
//# sourceMappingURL=net.resolve.js.map