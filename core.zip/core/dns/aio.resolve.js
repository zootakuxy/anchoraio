"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioResolver = exports.asAio = exports.domainMath = void 0;
const dns2_1 = require("dns2");
const fs = __importStar(require("fs"));
const ini_1 = __importDefault(require("ini"));
const localhost_1 = require("./localhost");
const dir_watch_1 = require("../utils/dir-watch");
const path_1 = __importDefault(require("path"));
function domainMath(domainName) {
    return new RegExp(`((^)*.${domainName})|((^)${domainName})$`);
}
exports.domainMath = domainMath;
function asAio(name) {
    let parts = name.split(".")
        .filter(value => value && value.length);
    if (parts.length < 2)
        parts.push("aio");
    if (parts[parts.length - 1] !== "aio")
        parts.push("aio");
    let identifier = parts.join(".");
    parts.pop();
    name = parts.join(".");
    return { name, identifier, match: domainMath(identifier) };
}
exports.asAio = asAio;
class AioResolver {
    constructor(agent) {
        this.servers = {};
        this.agents = agent;
        this.domains = {};
        this.address = {};
        this.servers = {};
        this.localhost = new localhost_1.Localhost(agent);
        this.dirWatch = new dir_watch_1.DirWatch();
        let bases = [
            { base: "resolve", "extension": "resolve.conf" }
        ];
        bases.forEach(value => {
            this.dirWatch.acceptor(path_1.default.join(this.agents.opts.etc, value.base), RegExp(`((^)*.${value.extension})|((^)${value.extension})$`));
        });
        let extension = "resolve.conf";
        let resolveRegexp = RegExp(`((^)*.${extension})|((^)${extension})$`);
        this.dirWatch.listener.on("reader", (list) => {
            list.forEach(filename => {
                if (resolveRegexp.test(filename))
                    this.onResolveFile(filename, { filename, basename: path_1.default.basename(filename), event: "write", dirname: path_1.default.dirname(filename) });
            });
        });
        this.dirWatch.listener.on("write", (filename, details) => {
            if (resolveRegexp.test(filename))
                this.onResolveFile(filename, details);
            console.log({
                domains: this.domains,
                address: this.address,
                servers: this.servers,
            });
        });
        this.dirWatch.start();
    }
    onResolveFile(filename, detect) {
        this.detachResolveFile(filename);
        if ((detect === null || detect === void 0 ? void 0 : detect.event) === "delete" || !fs.existsSync(filename))
            return;
        let resolve = ini_1.default.parse(fs.readFileSync(filename).toString());
        if (!resolve)
            resolve = {};
        resolve.domains = resolve.domains || {};
        console.log(resolve);
        console.log(resolve.domains);
        Object.entries(resolve.domains).forEach(([server, remotes]) => {
            console.log(server, remotes);
            let identifier = `${server}.aio`;
            this.servers[server] = {
                name: server,
                identifier,
                match: domainMath(identifier),
                reference: filename
            };
            Object.entries(remotes).forEach(([application, address]) => {
                console.log(server, application, address);
                let domainName = `${application}.${identifier}`;
                let resolved = {
                    reference: filename,
                    address,
                    server,
                    application,
                    domainName: domainName,
                    serverIdentifier: identifier
                };
                this.domains[domainName] = resolved;
                this.address[address] = resolved;
            });
        });
    }
    detachResolveFile(filename) {
        Object.entries(this.domains).forEach(([key, value]) => {
            if (value.reference === filename)
                delete this.domains[key];
        });
        Object.entries(this.address).forEach(([key, value]) => {
            if (value.reference === filename)
                delete this.address[key];
        });
        Object.entries(this.agents).forEach(([key, value]) => {
            if (value.reference === filename)
                delete this.agents[key];
        });
    }
    aioResolve(domainName) {
        let key = Object.keys(this.agents).find(next => { return this.agents[next].match.test(domainName); });
        let server = this.servers[key];
        if (!server)
            return null;
        let domain = this.domains[domainName];
        if (domain) {
            return [{ "name": domainName, "type": 1, "class": 1, "ttl": 300, "address": domain.address }];
        }
        let address;
        while (!address) {
            address = this.localhost.next();
            if (Object.keys(this.address).includes(address))
                address = null;
        }
        let application;
        let _domainParts = domainName.split(".");
        let _serverParts = server.identifier.split(".");
        if (_domainParts.length > _serverParts.length)
            application = _domainParts.shift();
        let answer = [{
                name: domainName,
                type: dns2_1.Packet.TYPE.A,
                class: dns2_1.Packet.CLASS.IN,
                ttl: 300,
                address: address
            }];
        if (!application)
            return [];
        let resolved = {
            reference: path_1.default.join(this.agents.opts.etc, "resolve", "dynamic.resolve.conf"),
            domainName: domainName,
            address: address,
            application,
            server: server.name,
            serverIdentifier: server.identifier
        };
        this.domains[domainName] = resolved;
        this.address[address] = resolved;
        let configs = {};
        Object.entries(this.servers).forEach(([key, _server]) => {
            configs[_server.name] = {};
            Object.entries(this.domains).filter(([key, value]) => {
                return value.reference === path_1.default.join(this.agents.opts.etc, "resolve", "dynamic.resolve.conf");
            }).forEach(([application, value]) => {
                configs[_server.name][value.application] = value.address;
            });
        });
        fs.writeFile(path_1.default.join(this.agents.opts.etc, "resolve", "dynamic.resolve.conf"), ini_1.default.stringify(configs, {
            whitespace: true
        }), () => { });
        return answer;
    }
    resolved(address) {
        return this.address[address];
    }
}
exports.AioResolver = AioResolver;
//# sourceMappingURL=aio.resolve.js.map