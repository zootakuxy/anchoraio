"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Localhost = exports.FIRST_ADDRESS = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const ini = __importStar(require("ini"));
const netaddr_1 = require("netaddr");
exports.FIRST_ADDRESS = "127.255.0.1";
class Localhost {
    constructor(agent) {
        this.agent = agent;
        let existsLocalhost = fs.existsSync(path.join(this.agent.opts.etc, "localhost.conf"));
        this._status = existsLocalhost ? ini.parse(fs.readFileSync(path.join(this.agent.opts.etc, "localhost.conf")).toString()) : { localhost: {} };
        let next;
        if (!this._status.localhost)
            this._status.localhost = {};
        if (!this._status.localhost.init)
            this._status.localhost.init = exports.FIRST_ADDRESS;
        if (!this._status.localhost.last) {
            next = this._status.localhost.init;
            this._status.localhost.last = this._status.localhost.init;
        }
        else
            next = (0, netaddr_1.Addr)(this._status.localhost.last).increment().octets.join(".");
        this._next = (0, netaddr_1.Addr)(next);
    }
    next() {
        let _next = this.current();
        this._next = this._next.increment();
        this._status.localhost.last = _next;
        fs.writeFile(path.join(this.agent.opts.etc, "localhost.conf"), ini.stringify(this._status), () => { });
        return _next;
    }
    current() {
        return this._next.octets.join(".");
    }
}
exports.Localhost = Localhost;
//# sourceMappingURL=localhost.js.map