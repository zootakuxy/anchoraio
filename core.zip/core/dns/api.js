"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentAPI = void 0;
const express_1 = __importDefault(require("express"));
const http = __importStar(require("http"));
const chalk_1 = __importDefault(require("chalk"));
const status_1 = require("../utils/status");
class AgentAPI {
    constructor(context) {
        this.context = context;
        this._status = new status_1.Status();
        this.app = (0, express_1.default)();
        const bodyParser = require('body-parser');
        this.app.use(bodyParser.json({}));
        this.app.use(bodyParser.urlencoded({ extended: true }));
        this.app.use(bodyParser.raw({}));
        this.app.use(bodyParser.text({}));
        this.app.get("/api/app/:application", (req, res, next) => {
            let application = req.params.application;
            let _app = this.context.agent.appManager.getApplication(application);
            console.log("[ANCHORIO] Agent> API>", `GET /api/application/${application}`);
            if (!_app)
                return res.json({ success: false });
            else
                return res.json({ success: true, data: _app });
        });
        this.app.post("/api/app/:application", (req, res, next) => {
            let application = req.params.application;
            let app = req.body;
            console.log("[ANCHORIO] Agent> API>", `POST /api/application/${application}`);
            let _app = this.context.agent.appManager.registerApplication(application, app);
            if (!_app)
                return res.json({ success: false });
            else
                return res.json({ success: true, data: _app });
        });
        this.app.get("/api/domain/:server", (req, res, next) => {
            let server = req.params.server;
            let answer = this.context.agent.aioResolve.aioResolve(server);
            console.log("[ANCHORIO] Agent> API>", `GET /api/domain/${server}`);
            return res.json({ success: !!answer && (answer === null || answer === void 0 ? void 0 : answer.length) > 0, data: answer });
        });
        this.app.get("/api/address/:address", (req, res, next) => {
            let address = req.params.address;
            console.log("[ANCHORIO] Agent> API>", `GET /api/address/${address}`);
            let resolved = this.context.agent.aioResolve.resolved(address);
            return res.json({ success: !!resolved && (resolved === null || resolved === void 0 ? void 0 : resolved.address), data: resolved });
        });
        this.app.get("/api/status", (req, res, next) => {
            console.log("[ANCHORIO] Agent> API>", `GET /api/status`);
            return res.json({ success: true, data: {
                    connected: this.context.agent.isConnected,
                    domain: this.context.agent.identifier,
                    port: this.context.options.agentPort,
                    serverHost: this.context.options.serverHost,
                    serverPort: this.context.options.serverPort,
                    serverConnection: this.context.agent.connect.id,
                } });
        });
        this.server = http.createServer({}, this.app);
        this._init();
    }
    _init() {
        if (!this.context.options.noAPI) {
            this.context.listener.on("context.start", any => {
                return this._status.start(() => {
                    return new Promise(resolve => {
                        this.server.listen(this.context.options.agentAPI, () => {
                            console.log("[ANCHORIO] Agent>", `Running Agent API ${this.context.options.identifier} on port ${chalk_1.default.greenBright(String(this.context.options.agentAPI))}`);
                            resolve(true);
                        });
                    });
                });
            });
            this.context.listener.on("context.stop", any => {
                return this._status.stop(() => {
                    return new Promise(resolve => {
                        this.server.close(err => { resolve(true); });
                    });
                });
            });
        }
    }
}
exports.AgentAPI = AgentAPI;
//# sourceMappingURL=api.js.map