"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DirWatch = void 0;
const listener_1 = require("./listener");
const fs_1 = __importDefault(require("fs"));
const recursive_watch_1 = __importDefault(require("recursive-watch"));
const path_1 = __importDefault(require("path"));
class DirWatch {
    constructor() {
        this.acceptors = [];
        this.exists = [];
        this.listener = new listener_1.Listener();
        this.acceptors = [];
    }
    acceptor(base, ...acceptors) {
        let index = this.acceptors.findIndex(value => value.base === base);
        if (index === -1)
            this.acceptors.push({ base, acceptors: acceptors });
        else
            this.acceptors[index] = { base, acceptors };
    }
    accept(base, fileName) {
        return !!this.acceptors.find(value => value.base === base
            && value.acceptors.find(value1 => value1.test(fileName)));
    }
    start() {
        this.exists.splice(0, this.exists.length);
        this.acceptors.forEach(value => {
            let list = this.rescan(value.base, value.base);
            this.exists.push(...list);
            this.listener.notify("base-reader", list);
        });
        this.listener.notify("reader", this.exists);
        this.acceptors.forEach(value => {
            this.watch(value.base);
        });
    }
    rescan(base, dirname) {
        let _files = [];
        if (!fs_1.default.existsSync(dirname))
            fs_1.default.mkdirSync(dirname);
        fs_1.default.readdirSync(dirname).forEach(basename => {
            let filename = path_1.default.join(dirname, basename);
            let relative = path_1.default.relative(base, filename);
            let state = fs_1.default.statSync(filename);
            if (state.isDirectory()) {
                return _files.push(...this.rescan(base, filename));
            }
            if (!state.isFile())
                return;
            if (!this.accept(base, relative))
                return;
            _files.push(filename);
        });
        return _files;
    }
    watch(base) {
        (0, recursive_watch_1.default)(base, (filename) => {
            let action;
            if (!this.accept(base, filename))
                return;
            if (fs_1.default.existsSync(filename) && !fs_1.default.statSync(filename).isFile())
                return;
            if (!fs_1.default.existsSync(filename))
                action = "delete";
            else if (fs_1.default.existsSync(filename) && !this.exists.includes(filename))
                action = "create";
            else if (fs_1.default.existsSync(filename) && this.exists.includes(filename))
                action = "change";
            if (action === "delete") {
                let index = this.exists.indexOf(filename);
                if (index !== -1)
                    this.exists = this.exists.splice(index, 1);
            }
            else if (action === "create")
                this.exists.push(filename);
            let basename = path_1.default.basename(filename);
            let relative = path_1.default.relative(base, filename);
            let dirname = path_1.default.dirname(filename);
            this.listener.notifyWith(action, relative, filename, { filename, basename, dirname, event: action });
            if (action === "create" || action === "change")
                this.listener.notifyWith("write", relative, filename, { filename, basename, dirname, event: action });
        });
    }
}
exports.DirWatch = DirWatch;
//# sourceMappingURL=dir-watch.js.map