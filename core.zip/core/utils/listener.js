"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Listener = void 0;
function arrayProxy() {
    return new Proxy({}, { get(target, p, receiver) {
            if (!target[p])
                target[p] = [];
            return target[p];
        } });
}
class Listener {
    constructor() {
        this.listen = {
            on: arrayProxy(),
            once: arrayProxy()
        };
    }
    on(event, regexp, callback) {
        this.register("on", event, regexp, callback);
    }
    once(event, regexp, callback) {
        this.register("once", event, regexp, callback);
    }
    register(group, event, regexp, callback) {
        let list = this.listen[group][event];
        let _regexp;
        let cb;
        if (typeof regexp === "function")
            cb = regexp;
        else if (typeof callback === "function")
            cb = callback;
        list.push({ regexp: _regexp, callback: cb });
    }
    notifyAllWith(event, check, ...data) {
        return this.notifySyncWith(`${event}:sync`, check, ...data).then(value => {
            this.notify(event, ...data);
        });
    }
    notifySyncWith(event, check, ...data) {
        return Promise.all([
            this.onceNotifySyncWith(event, check, ...data),
            this.onNotifySyncWith(event, check, ...data)
        ]).then(value => {
            return Promise.resolve(true);
        });
    }
    notifyAll(event, ...data) {
        return this.notifySync(`${event}:sync`, ...data).then(value => {
            this.notify(event, ...data);
        });
    }
    notifySync(event, ...data) {
        return this.notifySyncWith(event, null, ...data);
    }
    eval(test, listener, ...data) {
        if (test && listener.regexp && !listener.regexp.test(test))
            return;
        return listener.callback(...data);
    }
    notifyWith(event, check, ...data) {
        this.onceNotifyWith(event, check, ...data);
        this.onNotifyWith(event, check, ...data);
    }
    notify(event, ...data) {
        return this.notifyWith(event, null, ...data);
    }
    onNotifyWith(event, check, ...data) {
        let list = [...this.listen.on[event], ...this.listen.on["*"]];
        ;
        list.forEach(value => this.eval(check, value, ...data));
    }
    onNotify(event, ...data) {
        return this.onNotifyWith(event, null, ...data);
    }
    onceNotifyWith(event, check, ...data) {
        let list = this.listen.once[event].splice(0, this.listen.once[event].length);
        list.push(...this.listen.once["*"].splice(0, this.listen.once["*"].length));
        list.forEach(value => this.eval(check, value, ...data));
    }
    onceNotify(event, ...data) {
        return this.onceNotifyWith(event, null, ...data);
    }
    onNotifySyncWith(event, check, ...data) {
        let list = [...this.listen.on[event], ...this.listen.on["*"]];
        return this._syncCallbacks(check, list);
    }
    onNotifySync(event, ...data) {
        return this.onNotifySyncWith(event, null, this.listen.on[event]);
    }
    onceNotifySyncWith(event, check, ...data) {
        let list = this.listen.once[event].splice(0, this.listen.once[event].length);
        list.push(...this.listen.once["*"].splice(0, this.listen.once["*"].length));
        return this._syncCallbacks(check, list);
    }
    onceNotifySync(event, ...data) {
        return this.onceNotifySyncWith(event, null, ...data);
    }
    _syncCallbacks(check, callbacks, ...data) {
        return new Promise(resolve => {
            let next = () => {
                if (!callbacks.length)
                    resolve(true);
                let _next = callbacks.pop();
                if (_next.regexp && check && !_next.regexp.test(check))
                    return next();
                let response = _next.callback(...data);
                if (!(response instanceof Promise))
                    next();
                else
                    (response.then(value => next()).catch(reason => {
                        console.log("ListerCatchError", reason);
                    }));
            };
            next();
        });
    }
}
exports.Listener = Listener;
//# sourceMappingURL=listener.js.map