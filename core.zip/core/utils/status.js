"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Status = void 0;
class Status {
    constructor() {
        this._status = "stopped";
    }
    start(callback) {
        return new Promise(resolve => {
            if (this._status !== "stopped")
                return resolve(false);
            this._status = "starting";
            let end = (stt) => {
                this._status = stt;
                return resolve(this._status === "started");
            };
            let _result = callback();
            if (_result instanceof Promise) {
                _result.then(value => {
                    return end("started");
                }).catch(reason => {
                    return end("stopped");
                });
            }
            else
                return end("started");
        });
    }
    stop(callback) {
        return new Promise(resolve => {
            if (this._status !== "started")
                return resolve(false);
            this._status = "stopping";
            let end = (stt) => {
                this._status = stt;
                return resolve(this._status === "stopped");
            };
            let _result = callback();
            if (_result instanceof Promise) {
                _result.then(value => {
                    return end("stopped");
                }).catch(reason => {
                    return end("started");
                });
            }
            else
                return end("stopped");
        });
    }
    get status() {
        return this._status;
    }
}
exports.Status = Status;
//# sourceMappingURL=status.js.map