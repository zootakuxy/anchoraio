"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioServer = void 0;
const net_1 = __importDefault(require("net"));
const socket_1 = require("./socket");
const fs_1 = __importDefault(require("fs"));
const chalk_1 = __importDefault(require("chalk"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
function nanoid(len) {
    return String(Math.random() * 99999999999);
}
class AioServer {
    static pathFrom(...ctrl) {
        let _ctrl = path_1.default.join(...ctrl);
        if (os_1.default.platform() === "win32")
            return path_1.default.join("\\\\?\\pipe", _ctrl);
        else
            return _ctrl;
    }
    constructor(opts) {
        this._serial = new Proxy({}, {
            get(target, p, receiver) {
                if (!target[p])
                    target[p] = 0;
                return target[p]++;
            }
        });
        this._aioSockets = {};
        this._connectionListener = new Proxy({}, {
            get(target, p, receiver) {
                if (!target[p])
                    target[p] = [];
                return target[p];
            }
        });
        this._opts = opts;
        this._net = net_1.default.createServer((socket) => {
            let _isAuth;
            let opts = { id: this.nextId(), isConnected: true, isAuth() {
                    return _isAuth;
                } };
            opts.listenEvent = this.opts.listenEvent;
            let aioSocket = (0, socket_1.convertToAioSocket)(socket, opts);
            let _accept = (...data) => {
                _isAuth = true;
                if (this.opts.sendHeader)
                    aioSocket.send("auth", aioSocket.id, ...data);
                this.onAccept(aioSocket, ...data);
                return true;
            }, _reject = (...args) => {
                _isAuth = false;
                if (this.opts.sendHeader)
                    aioSocket.send("auth", null, ...args);
                else
                    aioSocket.close();
                this.onReject(aioSocket, ...args);
                return false;
            };
            if (typeof this.opts.auth === "function") {
                aioSocket.onceListen("chunk", chunk => {
                    let pack = chunk;
                    try {
                        pack = JSON.parse(pack);
                    }
                    catch (e) { }
                    this.opts.auth(aioSocket, pack, _accept, _reject);
                });
            }
            else
                _accept();
            aioSocket.on("close", hadError => {
                if (!!this._aioSockets[aioSocket.id])
                    delete this._aioSockets[aioSocket.id];
                else
                    delete this._aioSockets[aioSocket.id];
            });
            this._aioSockets[aioSocket.id] = aioSocket;
            this.onAttach(aioSocket);
            this.notifyConnection(aioSocket);
        });
    }
    get opts() {
        return this._opts;
    }
    get aioSockets() {
        return this._aioSockets;
    }
    onAttach(aioSocket) { }
    notifyConnection(aioConnection) {
        this._connectionListener.once.splice(0, this._connectionListener.on.length).forEach(value => value(aioConnection));
        this._connectionListener.on.forEach(onListener => onListener(aioConnection));
    }
    nextId() {
        let id = `${this.opts.namespace}://${this.opts.identifier}/${nanoid(16)}?${this._serial["id"]}`;
        if (!this._aioSockets[id])
            return id;
        else
            return this.nextId();
    }
    onConnection(onConnection) { this._connectionListener.on.push(onConnection); }
    onceConnection(onConnection) { this._connectionListener.once.push(onConnection); }
    of(id) {
        let socket;
        if (typeof id === "string")
            socket = this._aioSockets[id];
        else if (socket && typeof socket === "object")
            socket = id;
        return socket;
    }
    mergeMeta(id, meta) {
        if (!meta)
            return false;
        let socket = this.of(id);
        if (!socket)
            return false;
        if (!socket.meta)
            socket.meta = {};
        Object.assign(socket.meta, meta);
        return true;
    }
    mergeFromMeta(id, meta) {
        if (!meta)
            return false;
        let socket = this._aioSockets[id];
        if (!socket)
            return false;
        if (!socket.meta)
            socket.meta = {};
        let _currentMeta = socket.meta;
        socket.meta = meta;
        Object.assign(meta, _currentMeta);
        return true;
    }
    setMeta(id, meta) {
        let socket = this._aioSockets[id];
        if (!socket)
            return false;
        socket.meta = meta;
        return true;
    }
    socketOf(id) {
        return this._aioSockets[id];
    }
    broadcast(event, ...data) {
        // this.sockets.forEach( value => {
        //     if( value.connected ) value.send(event, ...data );
        // })
    }
    metaOf(id) {
        let socket = this.socketOf(id);
        if (!socket)
            return null;
        return socket.meta;
    }
    filterSocketByMeta(callback) {
        if (typeof callback !== "function")
            return null;
        return Object.keys(this._aioSockets).filter(value => {
            if (!this._aioSockets[value].meta)
                this._aioSockets[value].meta = {};
            return callback(this._aioSockets[value].meta, this._aioSockets[value]);
        }).map(value => this._aioSockets[value]);
    }
    findSocketByMeta(callback) {
        if (typeof callback !== "function")
            return null;
        let id = Object.keys(this._aioSockets).find(id => {
            if (!this._aioSockets[id].meta)
                this._aioSockets[id].meta = {};
            return callback(this._aioSockets[id].meta, this._aioSockets[id]);
        });
        if (!id)
            return null;
        return this._aioSockets[id];
    }
    inject(socket) {
        if (!socket.id)
            return false;
        if (!!this._aioSockets[socket.id])
            return false;
        this._aioSockets[socket.id] = socket;
        socket.on("close", hadError => this.eject(socket));
    }
    eject(...sockets) {
        sockets.map(socket => this.of(socket)).forEach(value => {
            if (!value)
                return;
            if (!this._aioSockets[value.id])
                return;
            delete this._aioSockets[value.id];
        });
    }
    get sockets() {
        return Object.values(this._aioSockets);
    }
    get ids() {
        return Object.keys(this._aioSockets);
    }
    get entries() {
        return Object.entries(this._aioSockets).map((value) => ({ key: value[0], value: value[1] }));
    }
    get net() {
        return this._net;
    }
    start(callback) {
        let self = this;
        let _listen = [];
        if (Array.isArray(this.opts.listen))
            _listen.push(...this.opts.listen);
        else
            _listen.push(this.opts.listen);
        _listen.forEach(value => {
            this.net.listen(value, () => {
                if (typeof callback === "function")
                    callback(value);
            });
        });
        this.net.on("error", err => {
            console.log("[launcher]", err);
            let address = err["address"];
            if (os_1.default.platform() !== "linux")
                return;
            if (err["code"] === "EADDRINUSE" && !!address && fs_1.default.existsSync(address)) {
                console.log("[launcher]", `Try restore address ${address}...`);
                let check = net_1.default.connect({ path: address });
                check.on('error', function (e) {
                    console.log("[launcher]", e);
                    if (e["code"] == 'ECONNREFUSED') {
                        fs_1.default.unlinkSync(address);
                        console.log("[elevate]", `Removed ctrl ${address}`, fs_1.default.existsSync(address));
                        self.net.listen(address, function () {
                            if (typeof callback === "function")
                                callback(address);
                        });
                    }
                });
                check.on("connect", () => check.end(() => {
                    console.log("[launcher]", `Try restore address ${address}... ${chalk_1.default.redBright("FAILED")}`);
                    if (typeof callback === "function")
                        callback(address, err);
                }));
            }
        });
    }
    stop(callback) {
        this.net.close(callback);
        this.sockets.forEach(value => value.close());
    }
    onAccept(aioSocket, ...param2) { }
    onReject(aioSocket, ...param2) { }
}
exports.AioServer = AioServer;
//# sourceMappingURL=server.js.map