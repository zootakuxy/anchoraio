"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unescapeChunk = exports.scapeRaw = exports.SCAPE_TO = exports.SCAPE_FORM = exports.END_CHUNK = exports.listenEventOnData = exports.convertToAioSocket = exports.errorOf = exports.Meta = void 0;
const lib_1 = require("../lib");
class Meta {
}
exports.Meta = Meta;
function errorOf(socket) {
    var _a;
    if (!((_a = socket === null || socket === void 0 ? void 0 : socket["_readableState"]) === null || _a === void 0 ? void 0 : _a["errored"]))
        return null;
    let port = socket["_readableState"]["errored"]["port"];
    let address = socket["_readableState"]["errored"]["address"];
    let host = socket["_readableState"]["errored"]["host"];
    let error = socket["_readableState"]["errored"]["code"];
    let errorNo = socket["_readableState"]["errored"]["errno"];
    return { port, address, host, error: error, errorNo };
}
exports.errorOf = errorOf;
function convertToAioSocket(socket, opts) {
    let _opts;
    if (typeof opts === "string")
        _opts = { id: opts, isConnected: false, auth: null };
    else if (opts && typeof opts === "object")
        _opts = opts;
    else
        _opts = { isConnected: false, auth: null };
    let aioSocket = socket;
    let _aio = {
        hadError: null,
        id: _opts.id,
        auth: false,
        meta: _opts.meta || {},
        autoReconnect: _opts.autoReconnect,
        connected: _opts.isConnected,
        send: function (raw) {
            // console.log( "SEND-RAW", aioSocket.connected, raw  )
            let chunk = scapeRaw(raw) + exports.END_CHUNK;
            if (aioSocket.connected)
                return socket.write(chunk);
            else
                _aio.pendents.push(chunk);
            // console.log("WRIT-IN-MODE", chalk.yellowBright( String( aioSocket.connected ), raw ))
            // socket.write(chunk);
        },
        pendents: [],
        on: lib_1.lib.proxyOfArray(),
        once: lib_1.lib.proxyOfArray(),
    };
    let registerEvent = (event, callback, collector) => {
        if (typeof event === "function") {
            callback = event;
            event = "chunk";
        }
        if (typeof callback !== "function")
            return;
        collector[event].push(callback);
    };
    let extension = {
        get id() { return _aio.id; },
        set id(id) {
            _aio.id = id;
        },
        isAuth() {
            if (typeof _opts.isAuth === "function")
                return _opts.isAuth();
            else
                return _aio.auth;
        },
        get connected() { return _aio.connected; },
        get meta() {
            if (!_aio.meta)
                _aio.meta = {};
            return _aio.meta;
        },
        reconnectTimeout: _opts.reconnectTimeout || 1000,
        send(event, ...data) {
            let raw = event;
            if (data.length > 0) {
                raw = JSON.stringify({
                    "aio-event-name": event,
                    "aio-event-args": data,
                });
            }
            _aio.send(raw);
        }, onListen(event, cb) {
            registerEvent(event, cb, _aio.on);
        }, onceListen(event, cb) {
            registerEvent(event, cb, _aio.once);
        }, notifyEvent(event, ...data) {
            [event, "*"].forEach(_event => {
                _aio.once[_event].splice(0, _aio.once[_event].length)
                    .forEach(value => {
                    if (typeof value !== "function")
                        return;
                    if (_event === "*")
                        return value(event, ...data);
                    // @ts-ignore
                    value(...data);
                });
                _aio.on[_event].forEach(value => {
                    if (typeof value !== "function")
                        return;
                    if (_event === "*")
                        return value(event, ...data);
                    // @ts-ignore
                    value(...data);
                });
            });
        }, get autoReconnect() {
            return _aio.autoReconnect;
        }, set autoReconnect(reconnect) {
            _aio.autoReconnect = reconnect;
            if (!aioSocket.connected && _aio.autoReconnect && _aio.hadError) {
                tryReconnect();
            }
        }, close() {
            if (!aioSocket.connected)
                return false;
            aioSocket.end(() => { });
        }
    };
    Object.defineProperties(aioSocket, Object.getOwnPropertyDescriptors(extension));
    function tryReconnect() {
        if (!aioSocket.autoReconnect)
            return;
        if (aioSocket.connected)
            return;
        if (typeof aioSocket.autoReconnect === "function") {
            let result = aioSocket.autoReconnect();
            if (result instanceof Promise)
                result.then(reconnectNow);
            else
                reconnectNow(result);
            return;
        }
        else
            reconnectNow(aioSocket.autoReconnect);
    }
    aioSocket.on("error", err => {
        _aio.connected = false;
        _aio.hadError = err;
        tryReconnect();
    });
    function reconnectNow(opt) {
        let _reconnectOpts;
        if (opt && typeof opt === "object")
            _reconnectOpts = opt;
        else
            _reconnectOpts = {};
        let timeout = aioSocket.reconnectTimeout;
        if (!timeout || Number.isNaN(timeout) || !Number.isFinite(timeout))
            timeout = 1000;
        if (!opt)
            opt = {};
        let error = errorOf(aioSocket);
        _reconnectOpts.port = _reconnectOpts.port || (error === null || error === void 0 ? void 0 : error.port);
        _reconnectOpts.host = _reconnectOpts.host || (error === null || error === void 0 ? void 0 : error.host) || (error === null || error === void 0 ? void 0 : error.address);
        if (!_reconnectOpts.port || !_reconnectOpts.host)
            return;
        setTimeout(() => {
            aioSocket.connect({ host: _reconnectOpts.host, port: _reconnectOpts.port });
        }, timeout);
    }
    aioSocket.onListen("auth", (identifier, ...data) => {
        if (!identifier)
            return aioSocket.close();
        _aio.id = identifier;
        _aio.auth = true;
        while (aioSocket.connected && _aio.pendents.length) {
            aioSocket.write(_aio.pendents.shift());
        }
    });
    socket.on("connect", () => {
        _aio.connected = true;
        let _authNow = (data) => {
            aioSocket.send(JSON.stringify(data));
        };
        let _authData = _opts.auth;
        if (typeof _authData === "undefined" || (typeof _authData === "object" && !_authData))
            return;
        if (typeof _authData !== "function")
            return _authNow(_authData);
        _authData = _authData();
        if (_authData instanceof Promise)
            return _authData.then(value => _authNow(value));
        return _authNow(_authData);
    });
    let listenData = listenEventOnData(aioSocket);
    aioSocket.on("data", listenData);
    aioSocket.on("close", hadError => {
        _aio.connected = false;
    });
    return aioSocket;
}
exports.convertToAioSocket = convertToAioSocket;
function listenEventOnData(aioSocket) {
    return data => {
        let _data = data.toString();
        if (!_data.length)
            return;
        let chunks = _data.split(exports.END_CHUNK);
        chunks.pop();
        chunks.forEach((chunk) => {
            chunk = unescapeChunk(chunk);
            let _object;
            try {
                _object = JSON.parse(chunk);
            }
            catch (e) {
                _object = null;
            }
            aioSocket.notifyEvent("chunk", chunk);
            if (!_object)
                return;
            if (!_object["aio-event-name"] || !_object["aio-event-args"])
                return;
            let [event, args] = [_object["aio-event-name"], _object["aio-event-args"]];
            if (!Array.isArray(args))
                return;
            aioSocket.notifyEvent(event, ...args);
        });
    };
}
exports.listenEventOnData = listenEventOnData;
//:END\n
//:END\\\n
exports.END_CHUNK = ":END\n";
exports.SCAPE_FORM = "\n";
exports.SCAPE_TO = "\\\n";
function scapeRaw(str) {
    if (!str)
        return null;
    return str.replace(new RegExp(`/(${exports.SCAPE_FORM})/g`), exports.SCAPE_TO);
}
exports.scapeRaw = scapeRaw;
function unescapeChunk(str) {
    if (!str)
        return null;
    return str.replace(new RegExp(`/(${exports.SCAPE_TO})/g`), exports.SCAPE_FORM);
}
exports.unescapeChunk = unescapeChunk;
//# sourceMappingURL=socket.js.map