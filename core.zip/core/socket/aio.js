"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.aio = void 0;
const net_1 = __importDefault(require("net"));
const socket_1 = require("./socket");
const server_1 = require("./server");
const path_1 = __importDefault(require("path"));
var aio;
(function (aio) {
    function connect(opts, host) {
        let _opts;
        if (opts && typeof opts === "object") {
            _opts = opts;
        }
        let socket;
        if (typeof opts === "number" && host)
            socket = net_1.default.connect(opts, host);
        else
            socket = net_1.default.connect(opts);
        if (!_opts)
            _opts = { listenEvent: true, isConnected: false };
        if (!Object.keys(_opts).includes("listenEvent"))
            _opts.listenEvent = true;
        return (0, socket_1.convertToAioSocket)(socket, _opts);
    }
    aio.connect = connect;
    function convert(socket, opts) {
        return (0, socket_1.convertToAioSocket)(socket, opts);
    }
    aio.convert = convert;
    function createServer(opts) {
        return new server_1.AioServer(opts);
    }
    aio.createServer = createServer;
    aio.Defaults = {
        //language=file-reference
        envFile: path_1.default.join(__dirname, "../../etc/anchorio.conf"),
        etc: path_1.default.join(__dirname, "../../etc/entry"),
        agentPort: 36900,
        agentAPI: 36901,
        serverPort: 36902,
        anchorPort: 36903,
        dnsPort: 53,
        chanel: 10,
        serverHost: "127.0.0.1",
        reconnectTimeout: 1000,
        maxSlots: 6,
        minSlots: 3,
        dns: ["8.8.8", "8.8.4.4"]
    };
})(aio = exports.aio || (exports.aio = {}));
//# sourceMappingURL=aio.js.map