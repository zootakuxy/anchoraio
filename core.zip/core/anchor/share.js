"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HEADER = exports.SIMPLE_HEADER = exports.Event = void 0;
var Event;
(function (Event) {
    Event["AIO"] = "Event.AIO";
    Event["AIO_CANCELLED"] = "Event.AIO_CANCELLED";
    Event["AIO_SEND"] = "Event.AIO_SEND";
    Event["AIO_REJECTED"] = "Event.AIO_REJECTED";
    Event["AIO_ANCHORED"] = "Event.AIO_ANCHORED";
    Event["AIO_RESTORE"] = "Event.AIO_RESTORE";
    Event["AIO_END_ERROR"] = "Event.AIO_END_ERROR";
    Event["SLOTS"] = "Event.SLOTS";
    Event["CHANEL_FREE"] = "Event.CHANEL_FREE";
    Event["AUTH_ACCEPTED"] = "Event.AUTH_ACCEPTED";
    Event["AUTH_REJECTED"] = "Event.AUTH_REJECTED";
    Event["AUTH_CHANEL"] = "Event.AUTH_CHANEL";
})(Event = exports.Event || (exports.Event = {}));
exports.SIMPLE_HEADER = {
    aioEndError: null,
    aio: null, authResult: null, auth: null, slot: null
};
exports.HEADER = new Proxy({}, {
    get(target, p, receiver) {
        if (!target[p])
            target[p] = (args) => args;
        return target[p];
    }, set(target, p, value, receiver) {
        return true;
    }
});
//# sourceMappingURL=share.js.map