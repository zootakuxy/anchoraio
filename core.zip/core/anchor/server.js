"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioAnchorServer = exports.reverseAioType = exports.AioType = exports.ConnectionSide = exports.TransactionDirection = void 0;
const server_1 = require("../socket/server");
const share_1 = require("./share");
const nanoid_1 = require("nanoid");
const chalk_1 = __importDefault(require("chalk"));
const lib_1 = require("../lib");
var TransactionDirection;
(function (TransactionDirection) {
    TransactionDirection["CLIENT_TO_SERVER"] = "TransactionDirection.CLIENT_TO_SERVER";
    TransactionDirection["SERVER_TO_CLIENT"] = "TransactionDirection.SERVER_TO_CLIENT";
})(TransactionDirection = exports.TransactionDirection || (exports.TransactionDirection = {}));
var ConnectionSide;
(function (ConnectionSide) {
    ConnectionSide["CLIENT_SIDE"] = "ConnectionSide.CLIENT_SIDE";
    ConnectionSide["SERVER_SIDE"] = "ConnectionSide.SERVER_SIDE";
})(ConnectionSide = exports.ConnectionSide || (exports.ConnectionSide = {}));
var AioType;
(function (AioType) {
    AioType["AIO_IN"] = "AioType.AIO_IN";
    AioType["AIO_OUT"] = "AioType.AIO_OUT";
})(AioType = exports.AioType || (exports.AioType = {}));
function reverseAioType(type) {
    if (type === AioType.AIO_IN)
        return AioType.AIO_OUT;
    if (type === AioType.AIO_OUT)
        return AioType.AIO_IN;
}
exports.reverseAioType = reverseAioType;
class AioAnchorServer extends server_1.AioServer {
    constructor(agent, opts) {
        super(Object.assign(opts, {
            namespace: opts.namespace || "aio"
        }));
        this.seq = 0;
        this._needAnchors = {
            [AioType.AIO_IN]: lib_1.lib.proxyOfArray(),
            [AioType.AIO_OUT]: lib_1.lib.proxyOfArray(),
        };
        this._restore = {
            [AioType.AIO_IN]: lib_1.lib.proxyOfArray(),
            [AioType.AIO_OUT]: lib_1.lib.proxyOfArray(),
        };
        this._aio = {
            [AioType.AIO_IN]: lib_1.lib.proxyOfArray(),
            [AioType.AIO_OUT]: lib_1.lib.proxyOfArray(),
        };
        this._anchorOpts = opts;
        this._minSlots = opts.minSlots || 0;
        this._maxSlots = opts.maxSlots || 0;
        this._anchorPoint = opts.anchorPoint;
        this._agent = agent;
    }
    get anchorOpts() {
        return this._anchorOpts;
    }
    get minSlots() {
        return this._minSlots;
    }
    get maxSlots() {
        return this._maxSlots;
    }
    get anchorPoint() {
        return this._anchorPoint;
    }
    get agent() {
        return this._agent;
    }
    onAttach(aioSocket) {
        this.mergeMeta(aioSocket, { auth: false, status: "unknown", pendents: [], anchorConnection: "lost", packCount: 0 });
        this._register(aioSocket, { anchorPoint: this.anchorPoint });
    }
    needAnchor(aioType, server, restoreRequest) {
        return new Promise((resolve, reject) => {
            let opts = {
                key: (0, nanoid_1.nanoid)(12),
                busy: true,
                restoreRequest
            };
            this._needAnchors[aioType][server].push({ opts: opts, callback: anchor => {
                    resolve(anchor);
                } });
            this.anchorOpts.onNeedAnchor(aioType, server, opts).catch();
        });
    }
    openAnchor(aioType, server) {
        return new Promise((resolve, reject) => {
            let opts = {};
            this._needAnchors[aioType][server].push({ opts: opts, callback: anchor => {
                    resolve(anchor);
                } });
            this.anchorOpts.onNeedAnchor(aioType, server, opts).catch();
        });
    }
    _register(aioSocket, opts) {
        super.mergeMeta(aioSocket, {});
        let aioAnchor = aioSocket;
        if (aioAnchor.meta.isAnchorable)
            return aioAnchor;
        aioAnchor.meta.isAnchorable = true;
        aioAnchor.meta.pendents = aioAnchor.meta.pendents || [];
        aioAnchor.meta.anchorStatus = "free";
        aioAnchor.meta.anchorPoint = opts.anchorPoint;
        let capture = (event, data) => {
            let capture = aioAnchor.meta.anchorStatus !== "busy" || aioAnchor.meta.pendents.length || aioAnchor.meta.anchorConnection !== "connected";
            if (capture) {
                let pack = {
                    sequence: this.seq++,
                    connection: aioAnchor.id,
                    buffer: data,
                    event: event
                };
                // console.log( "CAPTURED CHUNK", aioAnchor.meta.anchorStatus, aioAnchor.meta.pendents.length, aioAnchor.meta.anchorConnection, data.toString())
                aioAnchor.meta.pendents.push(pack);
            }
        };
        aioAnchor.on("data", (data) => { capture("data", data); });
        aioAnchor.on("end", () => capture("end"));
        aioAnchor.on("error", err => {
            if (!aioAnchor.meta.isAnchored)
                return;
            if (aioAnchor.meta.onError === "KEEP")
                return;
            if (aioAnchor.meta.onError === "END") {
                let other = this.of(aioAnchor.meta.anchorWith);
                if (other)
                    other.close();
                this.anchorOpts.emit(aioAnchor.meta.anchorWithOrigin, share_1.Event.AIO_END_ERROR, share_1.HEADER.aioEndError({
                    request: aioAnchor.meta.anchorRequest,
                    replayTo: aioAnchor.meta.anchorWithOrigin,
                    origin: aioAnchor.meta.server
                }));
                console.log("[ANCHORIO] Stop anchored par by error");
                return;
            }
            if (aioAnchor.meta.onError === "RESTORE") {
                console.log("[ANCHORIO]", `Restore connection for request ${aioAnchor.meta.anchorRequest} ...`);
                let current = this.of(aioAnchor.meta.anchorWith);
                if (current) {
                    current.meta.anchorConnection = "lost";
                    current.meta.anchorWith = null;
                    current.off("data", current.meta.dataRedirect);
                }
                this.needAnchor(aioAnchor.meta.aioType, aioAnchor.meta.server, aioAnchor.meta.anchorRequest).then(restore => {
                    restore.meta.anchorRequest = aioAnchor.meta.anchorRequest;
                    this.waitAnchor(restore, aioAnchor.meta.anchorRequest).then(other => {
                        if (other.meta.anchorConnection === "connected" || restore.meta.anchorConnection === "connected")
                            return;
                        this.restoreNow(restore, other, aioAnchor.meta.anchorRequest);
                    });
                });
            }
        });
        aioAnchor.on("end", () => {
        });
        aioAnchor.on("close", hadError => {
            // console.log( "ANCHOR-CLOSE", connection.id, hadError );
            if (!aioAnchor.meta.auth)
                return;
            if (!aioAnchor.meta.server)
                return;
            [AioType.AIO_IN, AioType.AIO_OUT].forEach(aio => {
                let index = this._aio[aio][aioAnchor.meta.server].indexOf(aioAnchor.id);
                if (index === -1)
                    return;
                delete this._aio[aio][aioAnchor.meta.server][index];
            });
        });
        return aioAnchor;
    }
    register(connection, opts) {
        this.inject(connection);
        return this._register(connection, opts);
    }
    auth(slots, referer, opts) {
        if (!slots.origin)
            throw new Error("[Anchoraio] No slot server identification!");
        if (!slots.aioType)
            throw new Error("[Anchoraio] No slot aioType marks!");
        slots.anchors.map(id => {
            return this.of(id);
        }).forEach(socket => {
            var _a, _b;
            socket.meta.auth = true;
            socket.meta.status = "authenticated";
            socket.meta.aioType = slots.aioType;
            socket.meta.server = slots.origin;
            socket.meta.referer = referer;
            socket.meta.onError = opts.onError;
            socket.meta.anchorName = opts.name;
            if (slots.busy === socket.id) {
                socket.meta.anchorStatus = "busy";
                this.busy(slots, socket);
            }
            else
                this._aio[slots.aioType][slots.origin].push(socket.id);
            if (slots.busy && ((_a = slots.needOpts) === null || _a === void 0 ? void 0 : _a.restoreRequest)) {
                socket.meta.anchorStatus = "busy";
                socket.meta.anchorRequest = (_b = slots.needOpts) === null || _b === void 0 ? void 0 : _b.restoreRequest;
                this.restore(slots, socket);
            }
        });
    }
    /** //Essa funcçao serve rapar aplicar os restauros pendetentes */
    restore(slot, restore) {
        //Procurar e aplicar os restauros pendentes
        let restorers = this._restore[slot.aioType][slot.origin];
        let _restores = restorers.splice(restorers.findIndex(value => {
            return value.opts.request === slot.restore.request;
        }), 1);
        //Quando encontrado restauros pendente aplica-los
        if (_restores.length) {
            _restores[0].callback(restore);
            return;
        }
        //Quando não encontrar nenhum restaure pendente procurar por conexões quebrada que mativerão-se na espera
        let other = this.otherOf(restore, slot.needOpts.restoreRequest);
        if (!other)
            return;
        if (other.meta.isAnchored && restore.meta.isAnchored)
            return;
        this.restoreNow(restore, other, slot.needOpts.restoreRequest);
    }
    restoreNow(restore, other, request) {
        if (other.meta.aioType === AioType.AIO_IN)
            this.anchor(other, restore, request, restore.meta.application);
        else
            this.anchor(restore, other, request, restore.meta.application);
        console.log("[ANCHORIO]", `Restore connection for request ${restore.meta.anchorRequest} ... ${chalk_1.default.greenBright("CONNECTION RESTORED!")}`);
    }
    busy(slots, socket) {
        let __needs = this._needAnchors[slots.aioType][slots.origin];
        let lostIndex = __needs.findIndex(value => { var _a; return ((_a = value.opts) === null || _a === void 0 ? void 0 : _a.key) === slots.needOpts.key; });
        if (lostIndex === -1)
            return;
        __needs.splice(lostIndex, 1).forEach(value => {
            value.callback(socket);
        });
    }
    nextSlot(aioType, server, anchor) {
        return new Promise((_resolve, reject) => {
            // setTimeout( ()=>{
            // console.log( "GET-NEXT-SLOT", aioType, server, anchor );
            let resolve = (res) => {
                res.meta.anchorStatus = "busy";
                _resolve(res);
                let counts = this.counts(aioType, server);
                if (counts < this._minSlots)
                    this.openAnchor(aioType, server).catch(err => { });
            };
            let freeSlot;
            if (anchor)
                return resolve(this.of(anchor));
            let array = this._aio[aioType][server];
            while (!freeSlot && array.length) {
                let id = array.shift();
                if (!id)
                    continue;
                freeSlot = this.of(id);
                if (freeSlot.meta.anchorStatus !== "free")
                    freeSlot = null;
            }
            if (freeSlot)
                return resolve(freeSlot);
            this.needAnchor(aioType, server).then(freeSlot => {
                if (!freeSlot)
                    return resolve(null);
                resolve(freeSlot);
            });
        });
    }
    counts(type, server) {
        return this._aio[type][server].filter(value => !!value).length;
    }
    anchor(fromClient, toServer, anchorRequest, application) {
        if (fromClient.meta.isAnchored && toServer.meta.isAnchored) {
            throw new Error(`Connection ${fromClient.id} already preview anchored!`);
        }
        fromClient.meta.isAnchored = true;
        toServer.meta.isAnchored = true;
        fromClient.meta.application = application;
        fromClient.meta.side = ConnectionSide.CLIENT_SIDE;
        if (!!this.agent)
            fromClient.meta.appConf = this.agent.appManager.getApplication(application);
        toServer.meta.application = application;
        toServer.meta.side = ConnectionSide.SERVER_SIDE;
        if (!!this.agent)
            toServer.meta.appConf = this.agent.appManager.getApplication(application);
        let fromPendent = fromClient.meta.pendents || [];
        let toPendent = toServer.meta.pendents || [];
        this.pipe(fromClient, toServer, anchorRequest, application);
        let reverse = { [fromClient.id]: toServer, [toServer.id]: fromClient };
        let direction;
        while (toPendent.length > 0 || fromPendent.length > 0) {
            let next;
            if (!toPendent.length) {
                next = fromPendent.shift();
                direction = TransactionDirection.CLIENT_TO_SERVER;
            }
            else if (!fromPendent.length) {
                next = toPendent.shift();
                direction = TransactionDirection.SERVER_TO_CLIENT;
            }
            else if (toPendent[0].sequence < fromPendent[0].sequence) {
                next = toPendent.shift();
                direction = TransactionDirection.SERVER_TO_CLIENT;
            }
            else {
                next = fromPendent.shift();
                direction = TransactionDirection.CLIENT_TO_SERVER;
            }
            if (!next)
                break;
            if (!!this.agent)
                next.buffer = this.agent.appManager.transform(fromClient.meta, next.buffer, direction);
            if (next.event === "data")
                reverse[next.connection].write(next.buffer);
            else if (next.event === "ready")
                reverse[next.connection].emit("ready");
            else if (next.event === "end")
                reverse[next.connection].close();
        }
    }
    pipe(fromClient, toServer, anchorRequest, application) {
        [{ _from: fromClient, _to: toServer, direction: TransactionDirection.CLIENT_TO_SERVER }, { _from: toServer, _to: fromClient, direction: TransactionDirection.SERVER_TO_CLIENT }].forEach(value => {
            let { _from, _to, direction } = value;
            _from.meta.dataRedirect = data => {
                if (_from.meta.pendents.length)
                    return;
                if (this.agent)
                    data = this.agent.appManager.transform(_from.meta, data, direction);
                _to.write(data);
                _from.meta.packCount++;
            };
            _from.meta.endRedirect = () => {
                if (_from.meta.pendents.length)
                    return;
                _to.close();
            };
            _from.on("data", _from.meta.dataRedirect);
            _from.on("end", _from.meta.endRedirect);
            _from.meta.anchorStatus = "busy";
            _from.meta.anchorConnection = "connected";
            _from.meta.anchorRequest = anchorRequest;
            _from.meta.anchorWith = _to.id;
            _from.meta.anchorWithOrigin = _to.meta.server;
        });
    }
    otherOf(restore, request) {
        return this.findSocketByMeta((meta, next) => {
            return (next.connected && meta.anchorWith === restore.id)
                || (next.meta.anchorRequest == request
                    && next.meta.aioType !== restore.meta.aioType
                    && next.id !== restore.id
                    && next.connected
                    && next.meta.anchorConnection !== "connected");
        });
    }
    waitAnchor(restore, request) {
        return new Promise((resolve) => {
            let other = this.otherOf(restore, request);
            if (other)
                return resolve(other);
            let restoreOpts = { request: request };
            this._restore[reverseAioType(restore.meta.aioType)][restore.meta.anchorWithOrigin].push({
                opts: restoreOpts,
                callback: (socket) => {
                    resolve(socket);
                }
            });
        });
    }
}
exports.AioAnchorServer = AioAnchorServer;
//# sourceMappingURL=server.js.map