import {AioType, NeedAnchorOpts} from "./server";

export enum Event {
    AIO="Event.AIO",
    AIO_CANCELLED="Event.AIO_CANCELLED",
    AIO_SEND="Event.AIO_SEND",
    AIO_REJECTED="Event.AIO_REJECTED",
    AIO_ANCHORED="Event.AIO_ANCHORED",
    AIO_RESTORE="Event.AIO_RESTORE",
    AIO_END_ERROR="Event.AIO_END_ERROR",

    SLOTS="Event.SLOTS",
    CHANEL_FREE="Event.CHANEL_FREE",

    AUTH_ACCEPTED="Event.AUTH_ACCEPTED",
    AUTH_REJECTED="Event.AUTH_REJECTED",
    AUTH_CHANEL="Event.AUTH_CHANEL",

}

export interface RestoreOpts {
    request:string
}

export const SIMPLE_HEADER = {
    aioEndError: null as {
        request:string,
        replayTo:string,
        origin:string,
    },
    aio: null as {
        origin:string,
        request:string,
        server:string,
        application:string|number,
        anchor_to?:string,
        anchor_form: string,
        domainName:string
    }, authResult: null as {
        auth:boolean
        private?:string,
        anchorPort?:number
        message?:string

    }, auth: null as {
        token:string,
        origin:string,
        server:string,
        level:"primary"|"secondary",
        referer?:string,
        instance:string

    }, slot: null as {
        aioType:AioType,
        origin:string,
        anchors:string[],
        busy?:string,
        restore?:RestoreOpts
        needOpts:NeedAnchorOpts,
    }
} as const;


export const HEADER :{ [p in keyof typeof SIMPLE_HEADER ]?:( (args: typeof SIMPLE_HEADER[p]) =>typeof SIMPLE_HEADER[p]) } = new Proxy( {}, {
    get(target: {}, p: keyof typeof SIMPLE_HEADER, receiver: any): any {
        if( !target[ p ] ) target[ p ] = ( args ) => args;
        return target[ p ];
    }, set(target: {}, p: string | symbol, value: any, receiver: any): boolean {
        return true;
    }
});
