"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioCentral = void 0;
const chalk_1 = __importDefault(require("chalk"));
const aio_central_listener_1 = require("./aio-central-listener");
const share_1 = require("../anchor/share");
const server_1 = require("../anchor/server");
const token_service_1 = require("../service/token.service");
class AioCentral {
    constructor(opts) {
        let self = this;
        this._opts = opts;
        this._tokenService = new token_service_1.TokenService(opts);
        this._anchorServer = new server_1.AioAnchorServer(null, {
            identifier: "@central",
            listen: [this.opts.anchorPort],
            sendHeader: true,
            maxSlots: opts.maxSlots,
            minSlots: opts.minSlots,
            anchorPoint: "CONNECTION",
            onNeedAnchor: (type, server, opts) => this.needAnchor(type, server, opts),
            emit(server, event, ...data) {
                self.listener.waitChanelOf(server).then(value => {
                    value.emit(event, ...data);
                });
            }
        });
        this._listener = new aio_central_listener_1.AioCentralListener(this);
    }
    get opts() {
        return this._opts;
    }
    get anchorServer() {
        return this._anchorServer;
    }
    get listener() {
        return this._listener;
    }
    get tokenService() {
        return this._tokenService;
    }
    needAnchor(type, server, opts) {
        return new Promise((resolve) => {
            let connection = this.listener.server.findSocketByMeta(meta => meta.server === server);
            if (!connection)
                resolve(null);
            connection.send(share_1.Event.SLOTS, share_1.HEADER.slot({
                anchors: [],
                aioType: type,
                origin: server,
                needOpts: opts,
            }));
        });
    }
    closeServer(currentAgent) {
        if (!currentAgent)
            return;
        this._anchorServer.filterSocketByMeta(meta => meta.referer === currentAgent.id).forEach(value => {
            value.close();
        });
        this._listener.server.filterSocketByMeta(meta => meta.referer === currentAgent.id).forEach(value => {
            value.close();
        });
        currentAgent.close();
    }
    start() {
        this._anchorServer.start(() => {
            console.log("[ANCHORAIO] Server>", `Running server anchor on port ${chalk_1.default.greenBright(String(this.opts.anchorPort))}`);
        });
        this._listener.start(() => {
            console.log("[ANCHORAIO] Server>", `Running server on port ${chalk_1.default.greenBright(String(this.opts.serverPort))}`);
        });
    }
}
exports.AioCentral = AioCentral;
//# sourceMappingURL=aio-central.js.map