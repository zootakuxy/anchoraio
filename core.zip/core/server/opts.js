"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverBuilderOptions = void 0;
const aio_1 = require("../socket/aio");
const lib_1 = require("../lib");
function serverBuilderOptions(yargs) {
    yargs.option("serverPort", { alias: ["p", "port"],
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.serverPort
    });
    yargs.option("anchorPort", { alias: ["P"],
        type: "number",
        coerce: lib_1.lib.typeParser.asInt,
        default: aio_1.aio.Defaults.anchorPort
    });
    return yargs;
}
exports.serverBuilderOptions = serverBuilderOptions;
//# sourceMappingURL=opts.js.map