"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AioCentralListener = void 0;
const server_1 = require("../socket/server");
const share_1 = require("../anchor/share");
const chalk_1 = __importDefault(require("chalk"));
const nanoid_1 = require("nanoid");
const server_2 = require("../anchor/server");
const lib_1 = require("../lib");
class AioCentralListener {
    constructor(central) {
        this._pendentAuth = lib_1.lib.proxyOfArray();
        this._central = central;
        let self = this;
        this._server = new server_1.AioServer({
            listen: [central.opts.serverPort],
            identifier: "@central",
            sendHeader: true,
            namespace: "agents",
            listenEvent: true,
            auth(aioSocket, args, accept, reject) {
                self.auth(aioSocket, args, accept, reject);
            }
        });
        this._server.onConnection(aioSocket => {
            aioSocket.meta.status = "unknown";
            aioSocket.onListen(share_1.Event.AIO, (args) => this.onCentralAio(aioSocket, args));
            aioSocket.onListen(share_1.Event.AUTH_CHANEL, (args) => this.onCentralAuthChanel(aioSocket, args));
            aioSocket.onListen(share_1.Event.SLOTS, (args) => this.onCentralSlot(aioSocket, args));
            aioSocket.onListen(share_1.Event.CHANEL_FREE, (args) => this.onCentralChanelFree(aioSocket, args));
            aioSocket.onListen(share_1.Event.AIO_ANCHORED, (args) => this.onCentralAioAnchored(aioSocket, args));
            aioSocket.onListen(share_1.Event.AIO_REJECTED, (args) => this.onCentralAioRejected(aioSocket, args));
            aioSocket.onListen(share_1.Event.AIO_END_ERROR, (args) => this.onCentralAioEndError(aioSocket, args));
            aioSocket.on("close", hadError => {
                this._central.closeServer(aioSocket);
            });
        });
    }
    auth(aioSocket, args, accept, reject) {
        let result = false;
        if (args.level === "primary")
            return this.onCentralAuth(aioSocket, args).then(value => {
                if (value.auth)
                    result = accept(value);
                else
                    result = reject(value);
            });
        if (args.level === "secondary")
            return this.onCentralAuthChanel(aioSocket, args).then(value => {
                if (value.auth)
                    result = accept(value);
                else
                    result = reject(value);
            });
        if (result)
            this.processPendents(aioSocket);
    }
    processPendents(aioSocket) {
        let pendents = this._pendentAuth[aioSocket.meta.server];
        pendents.splice(0, pendents.length).forEach(value => {
            if (!value.origin)
                return value.callback(aioSocket);
            let _origin = this.server.findSocketByMeta((meta, socket) => meta.server === value.origin
                && meta.channel === "primary");
            if (!_origin)
                return pendents.push(value);
            if (_origin.meta.instance === value.originInstance)
                return value.callback(aioSocket);
            else
                return value.callback(null);
        });
        Object.keys(this._pendentAuth).forEach(server => {
            pendents = this._pendentAuth[server];
            let index = 0;
            while (index < pendents.length) {
                let next = pendents[index];
                if (!next)
                    return;
                let chanel = this.chanelOf(server);
                if (!chanel)
                    return;
                if (!chanel.connected)
                    return;
                if (!chanel.isAuth())
                    return;
                if (next.origin === aioSocket.meta.server &&
                    next.originInstance === aioSocket.meta.instance) {
                    pendents.splice(index, 1);
                    next.callback(chanel);
                }
                else
                    index++;
            }
        });
    }
    get server() {
        return this._server;
    }
    get central() {
        return this._central;
    }
    onCentralAuth(aioSocket, authData) {
        return new Promise(resolve => {
            // aioSocket.pause();
            let reject = (message, code) => {
                aioSocket.meta.status = "rejected";
                // aioSocket.resume();
                console.log("[ANCHORIO] Server>", chalk_1.default.redBright(`Auth rejected for agent ${authData.server}. ${message}!`));
                return resolve({ auth: false, message });
            };
            if (!authData.server)
                return reject("Missing Agent Identifier", "no:server");
            if (!authData.origin)
                return reject("Missing Origin Identifier", "no:origen");
            if (!authData.instance)
                return reject("Missing Instance Identifier", "no:instance");
            if (!authData.token)
                return reject("Missing Token", "no:origin");
            if (authData.server !== authData.origin)
                return reject("Invalid origin", "bat:origin");
            this.checkToken(authData.server, authData.token).then(value => {
                if (!value)
                    return reject("Invalid token!", "bad:token");
                let currentAgent = this._server.findSocketByMeta(meta => meta.server === authData.server);
                this._central.closeServer(currentAgent);
                aioSocket.meta.server = authData.server;
                aioSocket.meta.status = "authenticated";
                aioSocket.meta.private = (0, nanoid_1.nanoid)(128);
                aioSocket.meta.channel = "primary";
                aioSocket.meta.instance = authData.instance;
                resolve({
                    auth: true,
                    anchorPort: this.central.opts.anchorPort,
                    private: aioSocket.meta.private
                });
                console.log("[ANCHORIO] Server>", chalk_1.default.greenBright(`Agent ${authData.server} connected with id ${aioSocket.id} `));
            });
        });
    }
    onCentralAuthChanel(aioSocket, args) {
        return new Promise(resolve => {
            aioSocket.meta.channel = "unknown";
            aioSocket.meta.channelStatus = "unknown";
            let reject = (message) => {
                aioSocket.close();
                console.log("[ANCHORIO] Server>", message, chalk_1.default.redBright(`Channel auth rejected`));
                return resolve({ auth: false, message });
            };
            if (!(args === null || args === void 0 ? void 0 : args.server))
                return reject(`Missing server of chanel!`);
            if (!(args === null || args === void 0 ? void 0 : args.referer))
                return reject(`Missing referer of chanel!`);
            if (!(args === null || args === void 0 ? void 0 : args.instance))
                return reject(`Missing instance of chanel!`);
            let primaryChanel = this.server.findSocketByMeta(meta => meta.server === args.server);
            if (!primaryChanel)
                return reject(`Server not found for chanel!`);
            if (primaryChanel.id !== args.referer)
                return reject(`Invalid referer`);
            if (aioSocket.isAuth())
                return /*aioSocket.resume()*/;
            aioSocket.meta.referer = primaryChanel.id;
            aioSocket.meta.server = primaryChanel.meta.server;
            aioSocket.meta.status = "authenticated";
            aioSocket.meta.channel = "secondary";
            aioSocket.meta.requests = 0;
            aioSocket.meta.channelStatus = "free";
            aioSocket.meta.instance = args.instance;
            return resolve({ auth: true, private: (0, nanoid_1.nanoid)(128) });
        });
    }
    checkToken(server, authToken) {
        return new Promise(resolve => {
            let { token } = this.central.tokenService.tokenOf(server);
            if (!token)
                return resolve(false);
            if (token.status !== "active")
                return resolve(false);
            if (authToken !== token.token)
                return resolve(false);
            else
                return resolve(true);
        });
    }
    onCentralChanelFree(aio, data) {
        if (!aio.isAuth())
            return;
        aio.meta.requests--;
        if (aio.meta.requests < 1)
            aio.meta.channelStatus = "free";
    }
    onCentralAio(origin, args) {
        if (!origin.isAuth())
            return;
        let reject = (message) => {
            console.log("[ANCHORIO] Server>", chalk_1.default.redBright `Anchor of request ${args.request} from ${args.anchor_form} to ${args.server} ${chalk_1.default.redBright("CANCELLED!")}`);
            origin.send(share_1.Event.AIO_CANCELLED, Object.assign(args, { canselMessage: message }));
        };
        let destine = this.chanelOf(args.server);
        if (!destine)
            return reject(`Agent Server not found!`);
        destine.meta.channelStatus = "busy";
        destine.meta.requests++;
        let out = this.central.anchorServer.nextSlot(server_2.AioType.AIO_OUT, origin.meta.server, args.anchor_form);
        let _in = this.central.anchorServer.nextSlot(server_2.AioType.AIO_IN, destine.meta.server);
        // origin.resume();
        Promise.all([out, _in]).then(value => {
            const [anchorOUT, anchorIN] = value;
            this.central.anchorServer.anchor(anchorOUT, anchorIN, args.request, args.application);
            console.log(destine.id);
            console.log(destine.connected);
            console.log(destine.meta);
            destine.send(share_1.Event.AIO, Object.assign(args, {
                anchor_to: anchorIN.id
            }));
            origin.send(share_1.Event.AIO_SEND, args);
            console.log("[ANCHORIO] Server>", `Anchor of request ${args.request} from ${args.anchor_form} to ${args.server} ${chalk_1.default.greenBright("AIO'K")}`);
        });
    }
    chanelOf(server) {
        let primaryChanel = this.server.findSocketByMeta((meta, socket) => meta.channel === "primary"
            && meta.server === server
            && !meta.referer
            && socket.connected
            && socket.isAuth());
        if (!primaryChanel)
            return;
        let serverChannels = this.server.filterSocketByMeta((meta, socket) => meta.channel === "secondary"
            && meta.server === server
            && meta.referer === primaryChanel.id
            && socket.connected
            && socket.isAuth()).sort((a, b) => a.meta.requests > b.meta.requests ? 1
            : a.meta.requests < b.meta.requests ? -1
                : 0);
        let destine = serverChannels.find(value => value.meta.channelStatus === "free");
        if (!destine) {
            serverChannels.push(primaryChanel);
            destine = serverChannels.shift();
        }
        return destine;
    }
    waitChanelOf(server, origin) {
        return new Promise(resolve => {
            let chanel = this.chanelOf(server);
            if (chanel)
                return resolve(chanel);
            let self = this;
            let pendentAuth = {
                origin: origin === null || origin === void 0 ? void 0 : origin.server,
                originInstance: origin === null || origin === void 0 ? void 0 : origin.instance,
                callback(chanel) {
                    resolve(chanel);
                }
            };
            this._pendentAuth[server].push(pendentAuth);
        });
    }
    onCentralSlot(aioSocket, slots) {
        if (!aioSocket.isAuth())
            return;
        this.central.anchorServer.auth(slots, aioSocket.meta.channel === "primary" ? aioSocket.id : aioSocket.meta.referer, { onError: "KEEP", name: `${slots.aioType}-CONNECTION` });
        console.log("[ANCHORIO] Server>", `${slots.anchors.length} connection anchors registered as ${slots.aioType} to ${aioSocket.meta.server}.`);
    }
    start(callback) { this._server.start(callback); }
    stop(callback) { this._server.stop(callback); }
    onCentralAioAnchored(aioSocket, args) {
        var _a;
        if (!aioSocket.isAuth())
            return;
        (_a = this.chanelOf(args.origin)) === null || _a === void 0 ? void 0 : _a.send(share_1.Event.AIO_ANCHORED, args);
    }
    onCentralAioRejected(aioSocket, args) {
        var _a;
        if (!aioSocket.isAuth())
            return;
        (_a = this.chanelOf(args.origin)) === null || _a === void 0 ? void 0 : _a.send(share_1.Event.AIO_REJECTED, args);
    }
    onCentralAioEndError(aioSocket, args) {
        this.central.anchorServer.filterSocketByMeta((meta, socket) => meta.anchorRequest === args.request
            && socket.connected).forEach(value => value.close());
        this.waitChanelOf(args.replayTo, aioSocket.meta).then(chanel => {
            if (!chanel)
                return;
            chanel.send(share_1.Event.AIO_END_ERROR, args);
        });
    }
}
exports.AioCentralListener = AioCentralListener;
//# sourceMappingURL=aio-central-listener.js.map