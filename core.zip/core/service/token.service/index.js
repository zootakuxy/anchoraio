"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenService = void 0;
const fs_1 = __importDefault(require("fs"));
const chalk_1 = __importDefault(require("chalk"));
const path_1 = __importDefault(require("path"));
const ini_1 = __importDefault(require("ini"));
const nanoid_1 = require("nanoid");
class TokenService {
    constructor(options) {
        this._opts = options;
    }
    get opts() {
        return this._opts;
    }
    start() {
        if (this.opts.list)
            return this.listAll();
        if (this.opts.identifier && this.opts.generate)
            return this.generateToken();
        if (this.opts.identifier && this.opts.update)
            return this.updateToken();
        if (this.opts.identifier)
            return this.showToken();
    }
    get folder() {
        if (!this._folder) {
            fs_1.default.mkdirSync(path_1.default.join(this.opts.etc, "token"), { recursive: true });
            this._folder = path_1.default.join(this.opts.etc, "token");
        }
        return this._folder;
    }
    get extension() {
        let _extension = "aio.conf";
        // return new RegExp( `((^)*.${_extension})|((^)${_extension})$`)
        return new RegExp(`((^)*.${_extension})$`);
    }
    listAll() {
        let _extension = this.extension;
        let list = [];
        fs_1.default.readdirSync(this.folder).filter(value => {
            return _extension.test(value);
        }).forEach(configName => {
            let _token = this.tokenOf(configName);
            if (!_token.token)
                return;
            list.push({
                identifier: _token.token.identifier,
                date: _token.token.date,
                filename: _token.filename,
                cfg: _token.confName,
                mail: _token.token.mail,
                status: _token.token.status
            });
        });
        if (this.opts.format === "table") {
            console.info("=========================== LIST OF TOKEN ===========================");
            console.table(list);
        }
        else if (this.opts.format === "json") {
            console.info(JSON.stringify(list));
        }
        else if (this.opts.format === "file") {
            list.forEach(value => console.info(value.filename));
        }
        else if (this.opts.format === "cfg") {
            list.forEach(value => console.info(value.cfg));
        }
        else if (this.opts.format === "label") {
            list.forEach((token, index) => {
                if (index > 0)
                    console.info("===============================================================");
                console.info("IDENTIFIER:", token.identifier);
                console.info("MAIL      :", token.mail);
                console.info("DATE      :", token.date);
                console.info("FILE      :", token.filename);
                console.info("CFG       :", token.cfg);
                console.info("STATUS    :", token.status);
            });
        }
        else if (this.opts.format === "ini") {
            console.info(ini_1.default.stringify(list));
        }
        return 0;
    }
    rawOf(confName) {
        if (!confName)
            return null;
        let confFile = path_1.default.join(this.folder, confName);
        if (!fs_1.default.existsSync(confFile))
            return null;
        return fs_1.default.readFileSync(path_1.default.join(this.folder, confName), "utf8").toString();
    }
    get token() {
        let { token } = this.tokenOf(this.opts.identifier);
        return token;
    }
    tokenOf(name) {
        let { confName, filename } = this.confNameOf(name);
        let raw = this.rawOf(confName);
        if (!raw)
            return {};
        let token = ini_1.default.parse(raw);
        if (!token.token)
            return {};
        if (!token.date)
            return {};
        if (!token.identifier)
            return {};
        if (!["active", "disable"].includes(token.status))
            return {};
        let json = JSON.stringify(token);
        return { raw, token, json, filename, confName };
    }
    confNameOf(identifier) {
        if (!identifier)
            identifier = this.opts.identifier;
        if (!identifier)
            return null;
        let _parts = identifier.split(".");
        if (_parts.length === 3 && _parts[0].length > 0 && _parts[1] === "aio" && _parts[2] === "conf")
            return {
                confName: identifier,
                filename: path_1.default.join(this.folder, identifier)
            };
        if (_parts.length !== 2)
            return {};
        identifier = `${identifier}.conf`;
        return {
            confName: identifier,
            filename: path_1.default.join(this.folder, identifier)
        };
    }
    showToken() {
        let { token, raw, filename, json, confName } = this.tokenOf(this.opts.identifier);
        if (!token) {
            console.error(chalk_1.default.redBright(`Token for identifier ${this.opts.identifier} not found or invalid!`));
            return -1;
        }
        let _self = this;
        let formats = ({ table() {
                console.info(`=========================== TOKEN OF ${_self.opts.identifier} ===========================`);
                console.table([token]);
            }, ini() {
                console.info(raw);
            }, label() {
                console.info("IDENTIFIER:", token.identifier);
                console.info("DATE      :", token.date);
                console.info("TOKEN     :", token.token);
            }, file() {
                console.info(filename);
            }, cfg() {
                console.info(confName);
            }, json() {
                console.info(json);
            }
        });
        if (!Object.keys(formats).includes(_self.opts.format)) {
            console.error(chalk_1.default.redBright(`Invalid format ${this.opts.format}`));
            return -1;
        }
        formats[_self.opts.format]();
        return 0;
    }
    updateToken() {
        let { confName } = this.confNameOf();
        if (!confName) {
            console.error(chalk_1.default.redBright('Missing identifier for generate token!'));
            return -1;
        }
        let currentToken = this.tokenOf(confName);
        if (!(currentToken === null || currentToken === void 0 ? void 0 : currentToken.token)) {
            console.error(chalk_1.default.redBright(`Token for identifier ${this.opts.identifier} not found or invalid`));
            return -1;
        }
        this.writeToken(currentToken.token.token, confName);
    }
    generateToken() {
        let { confName } = this.confNameOf();
        if (!confName) {
            console.error(chalk_1.default.redBright('Missing identifier for generate token!'));
            return -1;
        }
        let currentToken = this.tokenOf(confName);
        if ((currentToken === null || currentToken === void 0 ? void 0 : currentToken.token) && !this.opts.update) {
            console.error(chalk_1.default.redBright(`Already exists token to ${confName}. use [--update] to force generate`));
            return -1;
        }
        let check = Math.trunc((Math.random() * (9999 - 1000)) + 1000);
        let token = `${new Date().getTime()}:${(0, nanoid_1.nanoid)(128)}|${check}`;
        return this.writeToken(token, confName);
    }
    writeToken(_token, confName) {
        let token = {
            identifier: this.opts.identifier,
            date: new Date().toISOString(),
            token: _token,
            status: this.opts.status,
            mail: this.opts.mail
        };
        let tokenData = ini_1.default.stringify(token);
        fs_1.default.writeFileSync(path_1.default.join(this.folder, confName), tokenData);
        let t = this.opts.format;
        this.opts.format = "ini";
        let response = this.showToken();
        this.opts.format = t;
        return response;
    }
}
exports.TokenService = TokenService;
//# sourceMappingURL=index.js.map