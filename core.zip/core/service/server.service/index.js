"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerContext = void 0;
const aio_central_1 = require("../../server/aio-central");
class ServerContext {
    constructor(opts) {
        this.option = opts;
        this.server = new aio_central_1.AioCentral(opts);
    }
    start() {
        this.start = () => { console.log("[ANCHORIO] Server>", `This server context already started!`); };
        this.server.start();
    }
}
exports.ServerContext = ServerContext;
//# sourceMappingURL=index.js.map