"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentContext = void 0;
const api_1 = require("../../dns/api");
const server_1 = require("../../dns/server");
const aio_agent_1 = require("../../agent/aio-agent");
class AgentContext {
    constructor(agentOpts) {
        this.options = agentOpts;
    }
    start() {
        this.start = () => {
            console.log("Function already started!");
        };
        let agent = new aio_agent_1.AioAgent(this.options, this);
        this.agent = agent;
        if (agent.opts.selfServer) {
            agent.opts.serverHost = "127.0.0.1";
            const { ServerContext } = require('./../server.service');
            new ServerContext(agent.opts).start();
        }
        agent.start();
        // agent.connect().then( value => {
        //     console.log( "[ANCHORIO] Agent>", chalk.greenBright( `Connected to server on ${agent.opts.serverHost}:${String( agent.opts.serverPort )}` ) );
        //     agent.localListener.createServer().then( value1 => {});
        // });
        if (!agent.opts.noDNS) {
            this.agentDNS = new server_1.AgentDNS(agent);
        }
        if (!agent.opts.noAPI) {
            this.agentApi = new api_1.AgentAPI(agent);
        }
    }
}
exports.AgentContext = AgentContext;
//# sourceMappingURL=index.js.map