"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.discoverApplications = exports.Application = void 0;
const path_1 = __importDefault(require("path"));
const file_util_1 = require("zoo.util/lib/file-util");
class Application {
    constructor(_module) {
        let _name = path_1.default.relative(__dirname, _module.id);
        _name = _name.substring(0, _name.length - `app.${path_1.default.extname(_name)}`.length);
        this.name = _name;
    }
    transform(meta, data, config, direction) {
        return data;
    }
}
exports.Application = Application;
function discoverApplications() {
    let math = /.*.app.js$/;
    let apps = [];
    file_util_1.FileUtil.scanFiles(path_1.default.join(__dirname, /*language=file-reference*/ '../applications'), math, app => {
        let appInflate = require(app.path);
        if (!appInflate)
            return;
        if (typeof appInflate["createInstance"] !== "function")
            return;
        apps.push(appInflate["createInstance"]());
    }, { recursive: true });
    return apps;
}
exports.discoverApplications = discoverApplications;
//# sourceMappingURL=Application.js.map