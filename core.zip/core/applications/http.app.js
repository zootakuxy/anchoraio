"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInstance = exports.HttpApp = void 0;
const Application_1 = require("./Application");
const buffer_1 = require("buffer");
const server_1 = require("../anchor/server");
class HttpApp extends Application_1.Application {
    constructor() {
        super(module);
    }
    transform(meta, data, config, direction) {
        if (meta.side !== server_1.ConnectionSide.CLIENT_SIDE)
            return;
        let raw = data.toString();
        //1 -> Host: ${hostname}
        //8 -> Referer: ${}
        let lines = raw.split("\n");
        let _host;
        let host = (line) => {
            let parts = line.split("Host: ");
            if (parts.length !== 2)
                return null;
            _host = parts[1];
            return `Host: localhost:16519`;
        };
        let referer = (line) => {
            let parts = line.split("Referer: ");
            if (parts.length !== 2)
                return null;
            return `Referer: ${parts[1].replace('localhost:36900', 'localhost:16519')}`;
        };
        raw = lines.map(value => {
            let replace = host(value);
            if (!replace && _host)
                replace = referer(value);
            return replace || value;
        }).join("\n");
        return buffer_1.Buffer.from(raw);
    }
}
exports.HttpApp = HttpApp;
function createInstance() {
    return new HttpApp();
}
exports.createInstance = createInstance;
//# sourceMappingURL=http.app.js.map