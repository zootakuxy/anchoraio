"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInstance = void 0;
const Application_1 = require("./Application");
class PgApp extends Application_1.Application {
    constructor() {
        super(module);
    }
}
function createInstance() {
    return new PgApp();
}
exports.createInstance = createInstance;
//# sourceMappingURL=pg.app.js.map